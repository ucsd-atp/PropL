

from propositional_logic.random_gen.gen_dataset import *
from propositional_logic.random_gen.theorem_encoding import *
from propositional_logic.random_gen.data import *

P = Atom("p1")
Q = Atom("p2")
R = Atom("p3")

def gen_data(prop: Proposition) -> None:
    print("Generating data for", prop.__str__())
    create_datapoint(encode_prop(prop, 3), 3)

# p v q -> q v p
gen_data(Implies(Or(P, Q), Or(Q, P)))
# (r -> r) ^ ((p -> r) -> (q -> r)) ^ q -> p -> r
gen_data(Implies(
    And(Implies(R, R),
        And(Implies(Implies(P, P), Implies(Q, R)),
            Q
        )
    ),
    Implies(P,R)
))
# (p ^ q) v (p ^ (p -> q)) -> p ^ q
gen_data(Implies(
    Or(And(P, Q), And(P, Implies(P, Q))),
    And(P, Q)
))
