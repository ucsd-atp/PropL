from propositional_logic.random_gen.data import *
from propositional_logic.random_gen.to_lean import *
from propositional_logic.random_gen.get_lean_tactic_state import *
from propositional_logic.random_gen.proof_fail_check import *
from propositional_logic.random_gen.state_tracking_ctx import *

def find_last_line_indentation(text):
    lines = text.splitlines()
    
    # Find the index of the last non-empty line
    last_non_empty_line_index = None
    for i in range(len(lines) - 1, -1, -1):
        if lines[i].strip():  # Check if the line is not empty after stripping whitespace
            last_non_empty_line_index = i
            break
    
    if last_non_empty_line_index is not None:
        # Find the leading number of spaces in the last non-empty line
        last_line = lines[last_non_empty_line_index]
        indentation = last_line[:len(last_line) - len(last_line.lstrip())]
        if indentation == "":
            return "  "
        else:
            return indentation
    else:
        # If no non-empty lines are found, return 0 as default
        raise ValueError("all empyt lines")

class ProofFailEscape(Exception):
    pass


def traverse_proof(ctx: StateTrackingCtx, proof: Proof, next_tactic_num: int):
    result = ctx.result_buffer
    def recurse(p: Proof):
        return traverse_proof(ctx, p, 0)
    def show_tactic(tactic: str, tactic_num: int) -> None:
        to_append_tactic_text = f"state_{ctx.get_cur_state_num()}_tactic_{tactic_num}:\n"
        assert to_append_tactic_text not in ctx.result_buffer
        result.append(to_append_tactic_text)
        result.append(tactic + "\n")
    def new_state_with_new_tactic(tactic: str) -> None:
        ctx.push_state(ctx.get_cur_state_text() + "\n" + ctx.current_indent + tactic)
    def repeat_previous_state() -> None:
        ctx.push_state(ctx.get_cur_state_text())
    def show_current_tactic_state() -> None:
        result.append(f"state_{ctx.get_cur_state_num()}:\n")
        result.append(ctx.get_cur_tactic_state() + "\n")
    
    def inversion_one_step(tactic: str, tactic_num: int) -> None:
        show_tactic(tactic, tactic_num)
        new_state_with_new_tactic(tactic)
        show_current_tactic_state()
    def one_step_with_increment(tactic: str, tactic_num: int) -> None:
        show_tactic(tactic, tactic_num)
        new_state_with_new_tactic(tactic)
        ctx.increment_indent()
        show_current_tactic_state()
    def decrement_and_repeat_previous_state() -> None:
        ctx.decrement_indent()
        repeat_previous_state()
        show_current_tactic_state()

    def process_choices(choices: List[Proof]) -> None:
        cur_state_num = ctx.get_cur_state_num()
        if cur_state_num not in ctx.state_current_choices:
            ctx.state_current_choices[cur_state_num] = 0
        cur_indent = ctx.current_indent
        for _, c in enumerate(choices):
            result_len_before_choice = len(result)
            i = ctx.state_current_choices[cur_state_num]
            try:
                traverse_proof(ctx, c, i)
                break
            except ProofFailEscape:
                if len(result) > result_len_before_choice:
                    result.append(f"no solution, return to state {cur_state_num} [that leads to state {ctx.get_cur_state_num()}]\n")
                    ctx.set_cur_state_num(cur_state_num)
                    ctx.current_indent = cur_indent # reset indent
                    show_current_tactic_state()
                    ctx.state_current_choices[cur_state_num] += 1
                    continue
                else:
                    assert(ctx.get_cur_state_num() == cur_state_num)
                    assert f"state_{cur_state_num}_tactic_{i}:\n" not in ctx.result_buffer
                    # the branch did not make any progress, directly try next branch
                    raise ValueError("Each branch must be progressing")
                    continue



        else:
            raise ProofFailEscape()

    # state_indent = find_last_line_indentation(ctx.get_cur_state_text())
    top_level_tactics = get_top_level_lean_tactics("", proof)
    if len(top_level_tactics) == 0:
        match proof:
            case NegAtomR(subproof):
                return recurse(subproof)
            case UpshiftR(subproof):
                return recurse(subproof)
            case PosTrueL(name, subproof):
                return recurse(subproof)
            case PosAtomL(name, subproof):
                return recurse(subproof)
            case DownshiftL(name, subproof):
                return recurse(subproof)
            case StableSeq(subproof):
                return recurse(subproof)
            case FocusR(subproof):
                return recurse(subproof)
            case FocusL(name, subproof):
                return recurse(subproof)
            case UpshiftL(name, subproof):
                return recurse(subproof)
            case DownshiftR(subproof):
                return recurse(subproof)
            case ProofFailed():
                raise ProofFailEscape()
            case FocusChoice(choices):
                process_choices(choices)
                return
            case OrR_choice(l, r):
                process_choices([l, r])
                return
            case NegAndL_choice(l, r):
                process_choices([l, r])
                return
            case _:
                raise ValueError(f"Invalid proof: {proof}")
    if len(top_level_tactics) == 1:
        inversion_one_step(top_level_tactics[0], next_tactic_num)
        match proof:
            case ImpliesR((name, subproof)):
                recurse(subproof)
            case NegAndR(left, right):
                recurse(left)
                recurse(right)
            case NegTrueR():
                pass
            case FalseL(name):
                pass
            case OrR_left(subproof):
                recurse(subproof)
            case OrR_right(subproof):
                recurse(subproof)
            case PosAndR(left, right):
                recurse(left)
                recurse(right)
            case PosTrueR():
                pass
            case PosAtomR(name):
                pass
            case NegAndL_left(name, (left_name, left_proof)):
                recurse(left_proof)
            case NegAndL_right(name, (right_name, right_proof)):
                recurse(right_proof)
            case NegAtomL(name):
                pass
            case _:
                raise ValueError(f"Invalid proof: {proof}")
    else:
        match proof:
            case OrL(name, (left_name, left_proof), (right_name, right_proof)):
                inversion_one_step(top_level_tactics[0], next_tactic_num)
                one_step_with_increment(top_level_tactics[1], 0)
                recurse(left_proof)
                decrement_and_repeat_previous_state()
                one_step_with_increment(top_level_tactics[2], 0)
                recurse(right_proof)
                decrement_and_repeat_previous_state()
            case PosAndL(name, (left_name, right_name, subproof)):
                inversion_one_step(top_level_tactics[0], next_tactic_num)
                inversion_one_step(top_level_tactics[1], 0)
                recurse(subproof)
            case ImpliesL(name, prop, left, (right_name, right_proof), additional_name):
                one_step_with_increment(top_level_tactics[0], next_tactic_num)
                recurse(left)
                decrement_and_repeat_previous_state()
                inversion_one_step(top_level_tactics[1], 0)
                recurse(right_proof)
            case _:
                raise ValueError(f"Invalid proof: {proof}")










def get_thm_initial_state(num_vars: int, prop: Proposition) -> str:
    thm_text = to_lean_theorem_and_proof(5, prop, ProofFailed())
    tactic_state = StateTrackingCtx(num_vars, prop).get_cur_tactic_state()
    return tactic_state



def get_thm_proof_text_top_level(num_vars: int, prop: Proposition, proof: Proof) -> str:
    # assert MIN_TAE <= count_proof_failures(proof) <= MAX_TAE
    ctx = StateTrackingCtx(num_vars, prop)
    # ctx.push_state(get_thm_initial_state(num_vars, prop))
    # ret_text = "state_0_tactic_0:\n" + traverse_proof(ctx, proof)
    traverse_proof(ctx, proof, 0)
    ret_text = "".join(ctx.result_buffer)
    if not proof_has_failed(proof):
        ret_text += "proof is complete\n"
    else:
        ret_text += "proof failed\n"

    counted_proof_failure = count_proof_failures(proof)
    no_solution_occurrences = ret_text.count("no solution")
    if counted_proof_failure != no_solution_occurrences:
        raise ValueError(f"Proof failure count mismatch: {counted_proof_failure} vs {no_solution_occurrences}, proposition: ({encode_prop(prop, num_vars)}){prop}")

    return ret_text



    