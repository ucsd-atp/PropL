
import json
import subprocess


from propositional_logic.random_gen.data import *
from propositional_logic.random_gen.to_lean import *

class LeanError(Exception):
    pass

def get_lean_tactic_state(lean_text: str) -> str:
    # print("Getting tactic state for:")
    # print(lean_text)
    input_str = json.dumps({"cmd": lean_text})

    # Run the Lean REPL as a subprocess
    process = subprocess.Popen(["lake", "exec", "repl"], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, cwd="./lean-repl")
    
    try:
        # Feed the input JSON to the REPL via stdin
        stdout, stderr = process.communicate(input_str)

        # Parse the output JSON from stdout
        output_json = json.loads(stdout)
        if "sorries" not in output_json:
            raise LeanError(f"Output JSON does not contain 'sorries' field: {output_json}", lean_text)
        if len(output_json["sorries"]) == 0:
            return "no goals"
        elif len(output_json["sorries"]) == 1:
            ret_text = output_json["sorries"][0]["goal"]
            if ret_text == "unknown goal":
                return "no goals"
            else:
                return ret_text
        else:
            raise ValueError(f"More than one goal: {output_json['sorries']}")
    except json.JSONDecodeError as e:
        raise ValueError(f"Error decoding JSON: {e}", stdout, stderr)
    finally:
        # Kill the subprocess
        process.terminate()

if __name__ == "__main__":
    prompt = """
theorem thm_5_vars_84269451 : (((False ∨ (p4 → p1)) → (True ∨ p3)) ∧ True) := by
  apply And.intro
  intro h1
  apply True.intro
  sorry
"""
    result = get_lean_tactic_state(prompt)
    print("result is")
    print(result)