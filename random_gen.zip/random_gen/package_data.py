
import json
from propositional_logic.random_gen.gen_dataset import *
import zipfile
from datetime import datetime
from tqdm import tqdm

def package_encoding(num_vars: int) -> None:
    output_path_template = f"data_{num_vars}_vars/"
    with open(output_path_template + "_all_theorems.json", "r") as f:
        all_theorems = json.load(f)
    
    v1 = {}
    v2 = {}
    v3 = {}
    v3_2 = {}
    internal_nodes = {}
    proof_complexity = {}
    proof_complexity_v3 = {}
    proof_complexity_v3_2 = {}
    for encoding in tqdm(all_theorems):
        path_template = get_output_base_path_from_encoding(encoding, num_vars)
        with open(path_template + "v1.lean", "r") as f:
            v1[encoding] = f.read()
        with open(path_template + "v2.json", "r") as f:
            v2[encoding] = json.load(f)
        with open(path_template + "proof_complexity.json", "r") as f:
            proof_complexity[encoding] = json.load(f)
        with open(path_template + "v3.json", "r") as f:
            v3[encoding] = json.load(f)
        with open(path_template + "v3_2.json", "r") as f:
            v3_2[encoding] = json.load(f)
        with open(path_template + "proof_complexity_v3.json", "r") as f:
            proof_complexity_v3[encoding] = json.load(f)
        with open(path_template + "proof_complexity_v3_2.json", "r") as f:
            proof_complexity_v3_2[encoding] = json.load(f)
        with open(path_template + "internal_nodes.json", "r") as f:
            internal_nodes[encoding] = json.load(f)
    
    with open(output_path_template + "_v1.json", "w") as f:
        json.dump(v1, f)
    with open(output_path_template + "_v2.json", "w") as f:
        json.dump(v2, f)
    with open(output_path_template + "_proof_complexity.json", "w") as f:
        json.dump(proof_complexity, f)
    with open(output_path_template + "_v3.json", "w") as f:
        json.dump(v3, f)
    with open(output_path_template + "_v3_2.json", "w") as f:
        json.dump(v3_2, f)
    with open(output_path_template + "_proof_complexity_v3.json", "w") as f:
        json.dump(proof_complexity_v3, f)
    with open(output_path_template + "_proof_complexity_v3_2.json", "w") as f:
        json.dump(proof_complexity_v3_2, f)
    with open(output_path_template + "_internal_nodes.json", "w") as f:
        json.dump(internal_nodes, f)

    # create zip file
    with zipfile.ZipFile(f"data_{num_vars}_vars_{datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}.zip", 'w') as zf:
        zf.write(output_path_template + "_all_theorems.json")
        zf.write(output_path_template + "_v1.json")
        zf.write(output_path_template + "_v2.json")
        zf.write(output_path_template + "_proof_complexity.json")
        zf.write(output_path_template + "_v3.json")
        zf.write(output_path_template + "_v3_2.json")
        zf.write(output_path_template + "_proof_complexity_v3.json")
        zf.write(output_path_template + "_proof_complexity_v3_2.json")
        zf.write(output_path_template + "_internal_nodes.json")

if __name__ == "__main__":
    package_encoding(5)