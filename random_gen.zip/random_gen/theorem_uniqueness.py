
import sys
import os

import click
from propositional_logic.random_gen import data as e
from typing import *
from propositional_logic.theorem_processing import read_lean_file as readlean
from propositional_logic.random_gen import to_lean as to_lean
import re


known_theorems: Set[str] = set()

def extract_and_trim_text_between_colons(text):
    # Find the first ":" and the last ":=" in the text
    start_match = re.search(r':', text)
    end_match = re.search(r':=', text)

    if start_match and end_match:
        start_index = start_match.end()
        end_index = end_match.start()

        # Extract the text between the first ":" and the last ":=" and trim
        extracted_text = text[start_index:end_index].strip()
        return extracted_text

    # Return None if the pattern is not found
    return None

def add_new_theorem_text(prop_text: str) -> None:
    if prop_text not in known_theorems:
        known_theorems.add(prop_text)
    else:
        raise ValueError("Theorem already exists")


def add_new_theorem(prop: e.Proposition) -> None:
    prop_text = to_lean.to_lean_theorem_text(prop)
    add_new_theorem_text(prop_text)

def theorem_is_unique(prop: e.Proposition) -> bool:
    prop_text = to_lean.to_lean_theorem_text(prop)
    if prop_text in known_theorems:
        return False
    else:
        return True
    
def add_existing_lean_file(lean_file: str) -> None:
    theorems = readlean.get_theorems_and_proofs(lean_file)
    for (theorem, proof) in theorems:
        for l in theorem:
            if l.startswith('theorem'):
                prop_text = extract_and_trim_text_between_colons(l)
                if prop_text:
                    add_new_theorem_text(prop_text)
                else:
                    raise ValueError(f"Invalid theorem: {l}")
