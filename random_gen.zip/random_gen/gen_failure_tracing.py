from typing import *
import re


state_pattern  = re.compile(r'^state_(\d+):$')
state_tactic_pattern  = re.compile(r'^state_(\d+)_tactic_(\d+):$')
no_solution_pattern = re.compile(r'^no solution, return to state (\d+) \[that leads to state (\d+)\]$')

def trace_split_failure_top_level(base_path: str) -> int:
    # read file and process line by line
    with open(base_path + "v3.input.txt", 'r') as input_file_input:
        carry_lines = input_file_input.readlines()
    next_input_idx = 1
    next_output_idx = 1

    def write_next_input(lines: List[str]) -> None:
        nonlocal next_input_idx
        with open(base_path + f"v4.{next_input_idx}.input.txt", 'w') as output_file:
            output_file.writelines(lines)
        next_input_idx += 1

    def write_next_output(lines: List[str]) -> None:
        nonlocal next_output_idx
        with open(base_path + f"v4.{next_output_idx}.output.txt", 'w') as output_file:
            output_file.writelines(lines)
        next_output_idx += 1

    # write initial input first
    write_next_input(carry_lines)

    current_output_start_lino = len(carry_lines)
    cur_line_index = len(carry_lines)

    with open(base_path + "v3.output.txt", 'r') as input_file_output:
        carry_lines.extend(input_file_output.readlines())

    states = {0: 0} # state 0 occurs on the 0th position in carry lines
    tactics : Dict[int, Dict[int, int]]= {0: {}}
    states_mapping: Dict[int, int] = {0: 0} # mapping between original states and new states, 
    
    while cur_line_index < len(carry_lines):
        cur_line = carry_lines[cur_line_index].strip()
        state_match = state_pattern.match(cur_line)
        state_tactic_match = state_tactic_pattern.match(cur_line)
        no_solution_match = no_solution_pattern.match(cur_line)

        if state_match:
            original_state_num = int(state_match.group(1))
            if original_state_num not in states_mapping:
                state_num = len(states)
                assert state_num not in states
                assert state_num not in tactics
                assert original_state_num not in states_mapping
                states[state_num] = cur_line_index
                tactics[state_num] = {}
                states_mapping[original_state_num] = state_num
            carry_lines[cur_line_index] = f"state_{states_mapping[original_state_num]}:\n"
            cur_line_index += 1
        elif state_tactic_match:
            original_state_num = int(state_tactic_match.group(1))
            state_num = states_mapping[original_state_num]
            tactic_num = int(state_tactic_match.group(2))
            carry_lines[cur_line_index] = f"state_{state_num}_tactic_{tactic_num}:\n"
            assert tactic_num not in tactics[state_num]
            tactics[state_num][tactic_num] = cur_line_index
            cur_line_index += 1
        elif no_solution_match:
            original_ret_state_num = int(no_solution_match.group(1)) 
            original_prev_state_num = int(no_solution_match.group(2))
            carry_lines[cur_line_index] = f"no solution, return to state {states_mapping[original_ret_state_num]} [that leads to state {states_mapping[original_prev_state_num]}]\n"
            write_next_output(carry_lines[current_output_start_lino: cur_line_index + 1])
            ret_state_num = states_mapping[original_ret_state_num]
            ret_state_start_line = states[ret_state_num]
            ret_state_end_line = tactics[ret_state_num][0]
            failed_tactic_states = []
            # collect failed tactics and their states
            for tactic_num, tactic_line in tactics[ret_state_num].items():
                failed_tactic_states.extend(carry_lines[tactic_line:tactic_line+2] + ["failed\n"])
            for i in range(0, len(failed_tactic_states), 3):
                tactics[ret_state_num][i//3] = ret_state_end_line + i
            # truncate all content between ret_state_end_line and cur_line_index, 
            # and add in failed
            carry_lines = carry_lines[:ret_state_end_line] + failed_tactic_states + carry_lines[cur_line_index+1:]
            cur_line_index = ret_state_end_line + len(failed_tactic_states)
            current_output_start_lino = cur_line_index
            write_next_input(carry_lines[:cur_line_index])
            # remove all states that are larger than ret_state_num
            states_to_remove = [s for s in states if s > ret_state_num]
            assert len(states_to_remove) == max(states.keys()) - ret_state_num
            for s in states_to_remove:
                states.pop(s)
                tactics.pop(s)
        else:
            cur_line_index += 1

    write_next_output(carry_lines[current_output_start_lino:])
    return next_output_idx - 1

            
        
            

            
            




        






