# try to construct a proof using the focusing + chaining method

from propositional_logic.random_gen.data import *

from functools import reduce
from propositional_logic.random_gen.proof_complexity import calculate_complexity
from propositional_logic.random_gen.polarization import *
from time import time
from propositional_logic.random_gen.proof_choice_consolidation import *
from propositional_logic.random_gen.params import *   



class ProgressIndicator:
    def __init__(self):
        self.totals: List[int] = []
        self.completed: List[int] = []

    def begin_step(self, total: int):
        self.totals.append(total)
        self.completed.append(0)
        self.show_current_progress()

    def make_progress(self):
        self.completed.append(self.completed.pop() + 1)
        # self.show_current_progress()

    def end_step(self):
        self.totals.pop()
        self.completed.pop()

    def reset(self):
        self.totals = []
        self.completed = []

    def show_current_progress(self):
        # product together amount with self.factors
        # current_progress = 0.0
        # current_factor = 1.0
        # for i in range(len(self.totals)):
        #     current_progress += (self.completed[i]/self.totals[i]) * current_factor
        #     current_factor *= 1/self.totals[i]
        # print(f"\rProof Search Progress: {', '.join((f'{c}/{t}' for (c,t) in zip(self.completed, self.totals, strict=True)))}", end="")
        pass

# progress_indicator = ProgressIndicator()

# should_search_all = False

count = 0
def next_assump_name():
    global count
    count += 1
    return f"assump_{count}"

Ctx = List[Tuple[str, Proposition]]
Sequent = Tuple[Set[Proposition], Proposition]
RepCtx = List[Sequent]

def ctx_to_sequent(ctx: Ctx, right: Proposition) -> Sequent:
    return (set([p for (_, p) in ctx]), right)

def right_inverse(rep_ctx: RepCtx, stable_ctx : Ctx, unstable : Ctx, p : Proposition) -> Proof:
    match p:
        case Implies(left, right):
            new_name = next_assump_name()
            return ImpliesR(
                (new_name, right_inverse(rep_ctx, stable_ctx, [(new_name, left), *unstable], right))
                )
        case NegAnd(left, right):
            return NegAndR(
                right_inverse(rep_ctx, stable_ctx, unstable, left),
                right_inverse(rep_ctx, stable_ctx, unstable, right)
                )
        case PTrue():
            return NegTrueR()
        case NegAtom(name):
            return NegAtomR(left_inverse(rep_ctx, stable_ctx, unstable, p))
        case Upshift(operand):
            return UpshiftR(left_inverse(rep_ctx, stable_ctx, unstable, operand))
        case _:
            raise ValueError(f"Invalid proposition in right inverse: {p}")

def left_inverse(rep_ctx: RepCtx, stable_ctx : Ctx, unstable : Ctx, p : Proposition) -> Proof:
    match unstable:
        case []:
            return StableSeq(chaining(rep_ctx, stable_ctx, p))
        case [(name, prop), *rest]:
            new_name_1 = next_assump_name()
            new_name_2 = next_assump_name()
            match prop:
                case Or(left, right):
                    return OrL(name,
                        (new_name_1, left_inverse(rep_ctx, stable_ctx, [(new_name_1, left), *rest], p)),
                        (new_name_2, left_inverse(rep_ctx, stable_ctx, [(new_name_2, right), *rest], p))
                        )
                case PFalse():
                    return FalseL(name)
                case PosAnd(left, right):
                    return PosAndL(name,
                        (new_name_1, new_name_2, 
                         left_inverse(rep_ctx, stable_ctx, [(new_name_1, left), (new_name_2, right), *rest], p))
                        )
                case PTrue():
                    return PosTrueL(name, left_inverse(rep_ctx, stable_ctx, rest, p))
                case PosAtom(_):
                    return left_inverse(rep_ctx, [(name, prop), *stable_ctx], rest, p)
                case Downshift(operand):
                    return DownshiftL(name, 
                        left_inverse(rep_ctx, [(name, operand), *stable_ctx], rest, p))
                case _:
                    raise ValueError(f"Invalid proposition in left inverse: {p}")
        case _:
            raise ValueError(f"Invalid unstable context: {unstable}")


def chaining(rep_ctx: RepCtx, stable_ctx: Ctx, p : Proposition) -> Proof:
    if USE_COMPLETE_PROOF_SEARCH:
        this_sequent = ctx_to_sequent(stable_ctx, p)
        if this_sequent in rep_ctx:
            return ProofFailed()
        rep_ctx = [*rep_ctx, this_sequent]
    else:
        pass
    
    results: List[FocusL | FocusR] = []
    # progress_indicator.begin_step(len(stable_ctx) + 1)
    if not isinstance(p, NegAtom):
        proof_after_right_focus = right_focus(rep_ctx, stable_ctx, p)
        r_1 = FocusR(proof_after_right_focus)
        results.append(r_1)
    # progress_indicator.make_progress()
    for i,(name, prop) in enumerate(stable_ctx):
        if isinstance(prop, PosAtom):
            # progress_indicator.make_progress()
            continue
        if USE_COMPLETE_PROOF_SEARCH:
            new_stable_ctx = stable_ctx[:i] + stable_ctx[i:]
        else:
            new_stable_ctx = stable_ctx[:i] + stable_ctx[i+1:]
        rl = FocusL(name, left_focus(rep_ctx, new_stable_ctx, name, prop, p))
        results.append(rl)
    # progress_indicator.end_step()
    return FocusChoice(results)



def right_focus(rep_ctx: RepCtx, stable_ctx: Ctx, p : Proposition) -> Proof:
    match p:
        case Or(left, right):
                return OrR_choice(
                    OrR_left(right_focus(rep_ctx, stable_ctx, left)),
                    OrR_right(right_focus(rep_ctx, stable_ctx, right)))
        case PFalse():
            return ProofFailed()
        case PosAnd(left, right):
            return PosAndR(right_focus(rep_ctx, stable_ctx, left), right_focus(rep_ctx, stable_ctx, right))
        case PTrue():
            return PosTrueR()
        case PosAtom(name):
            match [assump_name for (assump_name, assump) in stable_ctx if assump == p]:
                case []:
                    return ProofFailed()
                case [assump_name, *rest]:
                    return PosAtomR(assump_name)
                case _:
                    raise ValueError("unrecognized value")
        case Downshift(operand):
            return DownshiftR(right_inverse(rep_ctx, stable_ctx, [], operand))
        case _:
            raise ValueError(f"Invalid proposition in right focus: {p}")
    


def left_focus(rep_ctx: RepCtx, stable_ctx: Ctx, name: str, prop: Proposition, p : Proposition) -> Proof:
    new_name = next_assump_name()
    new_name_2 = next_assump_name()
    match prop:
        case Implies(left, right):
            return ImpliesL(name, 
                left,
                right_focus(rep_ctx, stable_ctx, left),
                (new_name, left_focus(rep_ctx, stable_ctx, new_name, right, p)), 
                next_assump_name()
            )
        case NegAnd(left, right):
            return NegAndL_choice(
                NegAndL_left(name, (new_name, left_focus(rep_ctx, stable_ctx, new_name, left, p))),
                NegAndL_right(name, (new_name_2, left_focus(rep_ctx, stable_ctx, new_name_2, right, p)))
            )
        case PTrue():
            return ProofFailed()
        case NegAtom(fname):
            if p == prop:
                return NegAtomL(name)
            else:
                return ProofFailed()
        case Upshift(operand):
            return UpshiftL(name, left_inverse(rep_ctx, stable_ctx, [(name, operand)], p))
        case _:
            raise ValueError(f"Invalid proposition in left focus: {prop}")


def construct_proof_top_level(p : Proposition) -> Proof:
    start_time = time()
    # print("STARTING PROOF SEARCH")
    polarized = negative_polarize({}, p)
    # progress_indicator.reset()
    raw_proof =  (right_inverse([], [], [], polarized))
    result = refine_choice(raw_proof)
    end_time = time()
    # print("TOOK", end_time - start_time, "SECONDS")
    return result
    