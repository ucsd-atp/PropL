import functools
from propositional_logic.random_gen.data import *
import random
import decimal

from .params import *

@functools.cache
def catalan_number(n):
    """
    Calculate the nth Catalan number
    """
    assert n >= 0
    if n == 0:
        return 1
    elif n == 1:
        return 1
    else:
        acc = 0
        for i in range(0, n):
            acc += catalan_number(i) * catalan_number(n - i - 1)
        return acc

@functools.cache
def number_props_with_n_internal_nodes(internal_n: int, num_vars: int) -> int:
    """
    Calculate the number of propositions with n internal nodes
    """
    assert internal_n >= 0
    return catalan_number(internal_n) * (KIND_OF_INTERNAL_NODES ** internal_n) * ( (num_vars + KIND_OF_LEAF_NODES) ** (internal_n + 1))

@functools.cache
def cumulative_number_props_with_n_internal_nodes(internal_n: int, num_vars: int) -> int:
    """
    Calculate the cumulative number of propositions with n internal nodes
    """
    assert internal_n >= 0
    return sum(number_props_with_n_internal_nodes(i, num_vars) for i in range(0, internal_n + 1))

"""
Propositions are ordered by 
1. Number of internal nodes (less is first)
2. Number of internal nodes on the right (less is first) i.e., number of internal nodes on the left child (more is first)
3. T < F < And < Or < Implies
4. The (recursive order) of left child
5. The (recursive order) of right child
"""

def count_internal_nodes(p: Proposition) -> int:
    match p:
        case Atom(name):
            return 0
        case And(left, right):
            return 1 + count_internal_nodes(left) + count_internal_nodes(right)
        case Or(left, right):
            return 1 + count_internal_nodes(left) + count_internal_nodes(right)
        case Implies(left, right):
            return 1 + count_internal_nodes(left) + count_internal_nodes(right)
        case PTrue():
            return 0
        case PFalse():
            return 0
        case _:
            raise ValueError(f"Invalid proposition: {p}")

def encode_prop(p : Proposition, max_var_num : int):
    total_internal_nodes = count_internal_nodes(p)
    if total_internal_nodes == 0:
        leaf_candidates = [PTrue(), PFalse()]
        if p in leaf_candidates:
            return leaf_candidates.index(p)
        match p:
            case Atom(name):
                if name.startswith("p"):
                    p_num = int(name[1:])
                    assert p_num  <= max_var_num
                    return p_num + KIND_OF_LEAF_NODES - 1
                else:
                    raise ValueError(f"Invalid proposition: {p}")
            case _:
                raise ValueError(f"Should be atomic: {p}")
    else:
        prev_num = cumulative_number_props_with_n_internal_nodes(total_internal_nodes - 1, max_var_num)
        assert isinstance(p, And) or isinstance(p, Or) or isinstance(p, Implies)
        right_internal_nodes = count_internal_nodes(p.right)
        left_internal_nodes = total_internal_nodes - 1 - right_internal_nodes
        skip = 0
        # skip all previous internal node configurations
        for i in range(0, right_internal_nodes):
            skip += (
                #left
                number_props_with_n_internal_nodes(total_internal_nodes - 1 - i, max_var_num)
                #right
                * number_props_with_n_internal_nodes(i, max_var_num)
                * KIND_OF_INTERNAL_NODES
            )
        this_skip_coefficient: int
        if KIND_OF_INTERNAL_NODES == 3:
            if isinstance(p, And):
                this_skip_coefficient = 0
            elif isinstance(p, Or):
                this_skip_coefficient = 1
            elif isinstance(p, Implies):
                this_skip_coefficient = 2
            else:
                raise ValueError(f"Invalid proposition: {p}")
        elif KIND_OF_INTERNAL_NODES == 1:
            assert isinstance(p, Implies)
            this_skip_coefficient = 0
        else:
            raise ValueError(f"Invalid number of internal nodes: {KIND_OF_INTERNAL_NODES}")

        skip += (
            #left
            number_props_with_n_internal_nodes(left_internal_nodes, max_var_num)
            #right
            * number_props_with_n_internal_nodes(right_internal_nodes, max_var_num)
            * this_skip_coefficient
        )

        right_skip = number_props_with_n_internal_nodes(right_internal_nodes, max_var_num)
        left_encoding = encode_prop(p.left, max_var_num) \
            - (cumulative_number_props_with_n_internal_nodes(left_internal_nodes - 1, max_var_num) if left_internal_nodes > 0 else 0)
        right_encoding = encode_prop(p.right, max_var_num) \
            - (cumulative_number_props_with_n_internal_nodes(right_internal_nodes - 1, max_var_num) if right_internal_nodes > 0 else 0)
        return prev_num + skip + left_encoding * right_skip + right_encoding

def decode_prop(encoding: int, max_var_num: int) -> Proposition:
    assert encoding >= 0
    if encoding < max_var_num + KIND_OF_LEAF_NODES:
        if encoding < KIND_OF_LEAF_NODES:
            assert KIND_OF_LEAF_NODES <= 2
            return [PTrue(), PFalse()][encoding]
        else:
            return Atom(f"p{encoding - KIND_OF_LEAF_NODES + 1}")
    else:
        # find total number of internal nodes
        total_internal_nodes = 0
        while cumulative_number_props_with_n_internal_nodes(total_internal_nodes, max_var_num) <= encoding:
            total_internal_nodes += 1
        
        remaining_number = encoding - cumulative_number_props_with_n_internal_nodes(total_internal_nodes - 1, max_var_num)
        # find total number of internal nodes on the right
        right_internal_nodes = 0
        shape_cutoff = 0    
        while True:
            next_increment = (
                #left
                number_props_with_n_internal_nodes(total_internal_nodes - 1 - right_internal_nodes, max_var_num)
                #right
                * number_props_with_n_internal_nodes(right_internal_nodes, max_var_num)
                * KIND_OF_INTERNAL_NODES
            )
            if shape_cutoff + next_increment > remaining_number:
                break
            else:
                shape_cutoff += next_increment
                right_internal_nodes += 1
                if right_internal_nodes >= total_internal_nodes - 1:
                    break
        
        remaining_number -= shape_cutoff
        left_internal_nodes = total_internal_nodes - 1 - right_internal_nodes

        if KIND_OF_INTERNAL_NODES == 1:
            candidate_internal_nodes = [Implies]
        elif KIND_OF_INTERNAL_NODES == 3:
            candidate_internal_nodes = [And, Or, Implies]
        else:
            raise ValueError(f"Invalid number of internal nodes: {KIND_OF_INTERNAL_NODES}")
        # determine root node
        root_node = candidate_internal_nodes[
            remaining_number // (number_props_with_n_internal_nodes(right_internal_nodes, max_var_num)
            * number_props_with_n_internal_nodes(left_internal_nodes, max_var_num))
        ]

        remaining_number %= (number_props_with_n_internal_nodes(right_internal_nodes, max_var_num)
            * number_props_with_n_internal_nodes(left_internal_nodes, max_var_num))

        right_encoding = (remaining_number % number_props_with_n_internal_nodes(right_internal_nodes, max_var_num)) \
            + (cumulative_number_props_with_n_internal_nodes(right_internal_nodes - 1, max_var_num) if right_internal_nodes > 0 else 0)
        left_encoding = (remaining_number // number_props_with_n_internal_nodes(right_internal_nodes, max_var_num)) \
            + (cumulative_number_props_with_n_internal_nodes(left_internal_nodes - 1, max_var_num) if left_internal_nodes > 0 else 0)
        assert left_encoding < encoding
        assert right_encoding < encoding

        return root_node(decode_prop(left_encoding, max_var_num), decode_prop(right_encoding, max_var_num)) # type: ignore

def test_encode_decode():
    for i in range(10000):
        max_num_vars = 5
        prop_encoding = i

        prop = decode_prop(prop_encoding, max_num_vars)
        prop_encoding_2 = encode_prop(prop, max_num_vars)
        prop_2 = decode_prop(prop_encoding_2, max_num_vars)
        assert prop == prop_2
        assert prop_encoding == prop_encoding_2
    for i in range(10000):
        max_num_vars = random.randint(1, 100)
        prop_encoding = random.randint(1, cumulative_number_props_with_n_internal_nodes(10, max_num_vars))

        prop = decode_prop(prop_encoding, max_num_vars)
        prop_encoding_2 = encode_prop(prop, max_num_vars)
        prop_2 = decode_prop(prop_encoding_2, max_num_vars)
        assert prop == prop_2
        assert prop_encoding == prop_encoding_2


if __name__ == "__main__":
    print(decode_prop(58242, 5))
    for i in range(100):
        # print(f"{i}th catalan number: {catalan_number(i)}")
        print(f"Theorems with {i} internal nodes and 5 propositional variables: {decimal.Decimal(cumulative_number_props_with_n_internal_nodes(i, 5)):.6e}")
    # for i in range(500000000):
    #     print(f"With 5 propositional variables, the {i}th theorem is: {decode_prop(i, 5)}")
    # for i in range(10):
    #     prop_encoding = random.randint(1, cumulative_number_props_with_n_internal_nodes(20, 5))
    #     print(f"With 5 propositional variables, the {prop_encoding}th theorem is: {decode_prop(prop_encoding, 5)}")
    print("Testing theorem encoding")
    test_encode_decode()
    print("All tests passed")








        


        




