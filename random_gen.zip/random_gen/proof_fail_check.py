from propositional_logic.random_gen.data import *

def proof_has_failed(p: Proof) -> bool:
    class ProofHasFailed(Exception):
        pass
    def check_failure(p: Proof) -> Optional[Proof]:
        match p:
            case ProofFailed():
                raise ProofHasFailed()
            case FocusChoice(choices):
                if all([proof_has_failed(c) for c in choices]):
                    raise ProofHasFailed()
                else:
                    return "FAIL CHECK STUB" # cut off checking here
            case NegAndL_choice(l, r):
                if proof_has_failed(l) and proof_has_failed(r):
                    raise ProofHasFailed()
                else:
                    return "FAIL CHECK STUB"
            case OrR_choice(l, r):
                if proof_has_failed(l) and proof_has_failed(r):
                    raise ProofHasFailed()
                else:
                    return "FAIL CHECK STUB"
            case _:
                return None
    
    try:
        map_proof(check_failure, p)
        return False
    except ProofHasFailed:
        return True


def proof_contains_failure(p: Proof) -> bool:
    class ProofHasFailed(Exception):
        pass
    def check_failure(p: Proof) -> Optional[Proof]:
        match p:
            case ProofFailed():
                raise ProofHasFailed()
            case _:
                return None
    
    try:
        map_proof(check_failure, p)
        return False
    except ProofHasFailed:
        return True

def count_proof_failures(p: Proof) -> int:
    count = 0

    class FailCountException(Exception):
        pass
    def count_choices(choices: List[Proof]) -> [int, bool]:
        fail_counts = [count_proof_failures(c) for c in choices]
        return sum(fail_counts), all (proof_has_failed(c) for c in choices)
    def check_failure(p: Proof) -> Optional[Proof]:
        nonlocal count
        match p:
            case ProofFailed():
                count += 1
                raise FailCountException()
            case FocusChoice(choices):
                fail_counts, failed = count_choices(choices)
                count += fail_counts
                if failed:
                    count += 1
                    raise FailCountException()
                else:
                    return FocusChoice(choices)
            case NegAndL_choice(l, r):
                fail_counts, failed = count_choices([l, r])
                count += fail_counts
                if failed:
                    count += 1
                    raise FailCountException()
                else:
                    return NegAndL_choice(l, r)
            case OrR_choice(l, r):
                fail_counts, failed = count_choices([l, r])
                count += fail_counts
                if failed:
                    count += 1
                    raise FailCountException()
                else:
                    return OrR_choice(l, r)
            # case PosAndR(l, r):
            #     count += count_proof_failures(l)
            #     # for pos and, if left branch has failed, then it will back track directly
            #     if not proof_has_failed(l):
            #         count += count_proof_failures(r)
            #     else:
            #         pass
            #     return PosAndR(l, r)
            # case OrL(n, l, r):
            #     count += count_proof_failures(l[1])
            #     # only add right case if left case succeeds
            #     if not proof_has_failed(l[1]):
            #         count += count_proof_failures(r[1])
            #     else:
            #         pass
            #     return OrL(n, l, r)
            case _:
                return None
    
    try:
        map_proof(check_failure, p)
    except FailCountException:
        pass
    return count
