
# This controls complexity in terms of the amount of Trial And Error (TAE), both inclusive
MIN_TAE = 10
MAX_TAE = 10

# Theorems are randomly sampled from this range, discarding theorems that are not provable
# MIN_THEOREM_NUMBER = 0
# MAX_THEOREM_NUMBER = 10 ** 30

NUM_VARS = 5

# TOTAL_THEOREMS_TO_GENERATE = 10000

# this should be set to the reciprocal of ratio of provable theorems over all theorems
# this is used to speed up parallel processing of the generation of data
PARALLEL_SUCCESS_RATE_MULTIPLIER = 2
NON_PARALLEL_SUCCESS_RATE_MULTIPLIER = 5000


# Tuning parallel performs, this parameter should be set no more than the number of cores
NUM_WORKERS = 40
# The number of jobs that each batch should contain when generating theorems in parallel
CHUNK_SIZE = 4


# 3 : AND OR IMPLIES
# 1 : IMPLIES
KIND_OF_INTERNAL_NODES = 3


# 2 : TRUE and FALSE
# 0 : ATOMIC
KIND_OF_LEAF_NODES = 2

USE_COMPLETE_PROOF_SEARCH = False
