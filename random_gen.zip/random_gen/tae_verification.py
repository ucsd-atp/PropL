
from propositional_logic.random_gen.gen_dataset import *
from propositional_logic.random_gen.theorem_encoding import *
from propositional_logic.random_gen.data import *
from tqdm import tqdm
from propositional_logic.random_gen.package_data import *
from propositional_logic.random_gen.params import *
import matplotlib.pyplot as plt

designated = [321595135896271280856073162283]

def tae_verification() -> Dict[int, int]:
    for i in tqdm(range(10000)):
        while True:
            if i < len(designated):
                encoding = designated[i]
            else:
                encoding = random.randint(0, 10 ** 30)
            prop = decode_prop(encoding, NUM_VARS)
            proof = construct_proof_top_level(prop)
            if proof_has_failed(proof):
                if i < len(designated):
                    raise ValueError(f"designated {i} failed")
                continue
            proof = commit_drop_additional_choices_after_first_success(proof)
            assert not proof_has_failed(proof)
            tae = count_proof_failures(proof)
            v3_text = get_thm_proof_text_top_level(NUM_VARS, prop, proof)
            no_solution_occurrences = v3_text.count("no solution")
            if no_solution_occurrences != tae:
                raise ValueError(f"TAE DISAGREE: tae: {tae}, no_solution_occurrences: {no_solution_occurrences}")


if __name__ == "__main__":
    distribution = tae_verification()