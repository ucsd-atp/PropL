
from __future__ import annotations
from dataclasses import dataclass
import typing
from typing import *
import random
import z3
from propositional_logic.random_gen.data import *

def is_valid(expr: Proposition) -> bool:
    # Create a Z3 solver instance
    solver = z3.Solver()

    # Create a dictionary to map Atom names to Z3 variables
    vars = {}
    for name in freeVars(expr):
        vars[name] = z3.Bool(name)

    # Convert the proposition to a Z3 expression
    def to_z3(p: Proposition) -> z3.ExprRef:
        match p:
            case Atom(name):
                return vars[name]
            case Not(operand):
                return z3.Not(to_z3(operand))
            case And(left, right):
                return z3.And(to_z3(left), to_z3(right))
            case Or(left, right):
                return z3.Or(to_z3(left), to_z3(right))
            case Implies(left, right):
                return z3.Implies(to_z3(left), to_z3(right))
            case Iff(left, right):
                return z3.And(z3.Implies(to_z3(left), to_z3(right)), z3.Implies(to_z3(right), to_z3(left)))
            case PTrue():
                return z3.BoolVal(True)
            case PFalse():
                return z3.BoolVal(False)
            case _:
                raise ValueError(f"Invalid proposition: {p}")

    # Add the negation of the proposition to the solver
    solver.add(z3.Not(to_z3(expr)))

    # Check if the solver is unsatisfiable (i.e., the proposition is valid)
    return solver.check() == z3.unsat


