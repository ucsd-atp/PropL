import os
import json
from tqdm import tqdm
import zipfile
from datetime import datetime
from propositional_logic.random_gen.output_path_util import *
from propositional_logic.random_gen.gen_failure_tracing import *

def populate_v3_from_json(v3_json, theorem_encoding: int) -> None:
    output_base_path = get_output_base_path_from_encoding(theorem_encoding, 5)
    if os.path.exists(output_base_path + "v3.input.txt") and os.path.exists(output_base_path + "v3.output.txt"):
        return
    else:
        with open(output_base_path + "v3.input.txt", "w") as f:
            f.write(v3_json[str(theorem_encoding)]["input"])
        with open(output_base_path + "v3.output.txt", "w") as f:
            f.write(v3_json[str(theorem_encoding)]["output"])
        

def create_single_v4(theorem_encoding: int) -> None:
    output_base_path = get_output_base_path_from_encoding(theorem_encoding, 5)

    #v4
    if not os.path.exists(output_base_path + "v4.json"):
        v4_num = trace_split_failure_top_level(output_base_path)
        for i in range(v4_num):
            with open(output_base_path + f"v4.{i+1}.input.txt", "r") as f:
                input = f.read() 
            with open(output_base_path + f"v4.{i+1}.output.txt", "r") as f:
                output = f.read()
            with open(output_base_path + f"v4.{i+1}.json", "w") as f:
                json.dump({"input": input, "output": output}, f)
        with open(output_base_path + "v4.json", "w") as f:
            json.dump({"completed": v4_num}, f)
    
def package_v4_encoding(limit: int, num_vars: int) -> None:

    output_path_template = f"data_{num_vars}_vars/"

    with open(output_path_template + "_all_theorems.json", "r") as f:
        all_theorems = json.load(f)

    assert len(all_theorems) == limit

    v4 = {}
    for encoding in tqdm(all_theorems):
        path_template = get_output_base_path_from_encoding(encoding, num_vars)
        with open(path_template + "v4.json", "r") as f:
            v4_meta = json.load(f)
            v4[encoding] = {}
            for i in range(v4_meta["completed"]):
                with open(path_template + f"v4.{i+1}.json", "r") as f:
                    v4[encoding][i] = json.load(f)
    
    with open(output_path_template + "_v4.json", "w") as f:
        json.dump(v4, f)

    # create zip file
    with zipfile.ZipFile(f"data_{num_vars}_vars_{datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}.zip", 'w') as zf:
        zf.write(output_path_template + "_all_theorems.json")
        zf.write(output_path_template + "_v4.json")

    
def gen_all_v4():
    print("Loading _all_theorems.json")
    with open("data_5_vars/_all_theorems.json", "r") as f:
        all_theorems_raw = json.load(f)
    print("Loading _v3.json")
    with open("data_5_vars/_v3.json", "r") as f:
        v3_json = json.load(f)
    limit = 450000
    all_theorems = [int(k) for k in all_theorems_raw]
    assert (len(all_theorems) == limit)


    # geration
    for id in tqdm(all_theorems):
        populate_v3_from_json(v3_json, id)
        create_single_v4(id)

    # package encoding
    package_v4_encoding(limit, 5)


    
if __name__ == "__main__":
    gen_all_v4()

