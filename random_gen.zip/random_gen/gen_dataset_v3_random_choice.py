

import os
from propositional_logic.random_gen.theorem_encoding import *
from propositional_logic.random_gen.proof_construction import *
from propositional_logic.random_gen.proof_fail_check import *
from propositional_logic.random_gen.to_lean import *
from propositional_logic.random_gen.consolidate_choices import *
from propositional_logic.random_gen.assumption_renaming import *
from propositional_logic.random_gen.to_training import *
from propositional_logic.random_gen.proof_complexity import *
from propositional_logic.random_gen.gen_failure_tracing import *
from propositional_logic.random_gen.gen_dataset import *
from propositional_logic.random_gen.gen_5_vars_dataset import *
from tqdm import tqdm
import os

RANDOM_CHOICE_NUMBER = 10





def create_v3_random_datapoint(encoding: int, num_vars: int = NUM_VARS) -> None:
    os.makedirs(f"data_{num_vars}_vars", exist_ok=True)
    prop = decode_prop(encoding, num_vars)
    proof = construct_proof_top_level(prop)
    # print("proof tae start ", count_proof_failures(proof))


    if proof_has_failed(proof):
        print("WARNING: proof has failed for", encoding, num_vars)
        return
        # raise ValueError("Proof has failed, cannot create a datapoin for failed proofs", prop, proof)

    original_output_base_path = get_output_base_path(prop, encoding, num_vars)

    # v3
    for i in range(RANDOM_CHOICE_NUMBER):
        output_base_path = original_output_base_path + f"{i}."
        if not os.path.exists(output_base_path + "v3.json") or not os.path.exists(output_base_path + "v3_2.json"):
            shuffled_proof = shuffle_choices(proof)
            dropped_proof = commit_drop_additional_choices_after_first_success(shuffled_proof)
            # v3
            if True:
                backtracking_proof = rename_assumption_top_level(dropped_proof)
                # print("proof tae v3 ", count_proof_failures(backtracking_proof))
                v3_input = "state_0:\n" + get_thm_initial_state(num_vars, prop) + "\n"
                v3_output = get_thm_proof_text_top_level(num_vars, prop, backtracking_proof)
                with open(output_base_path + "v3.input.txt", "w") as f:
                    f.write(v3_input)
                with open(output_base_path + "v3.output.txt", "w") as f:
                    f.write(v3_output)
                with open(output_base_path +  "v3.json", "w") as f:
                    json.dump({"input": v3_input, "output": v3_output}, f)

            if True:
                backtracking_proof_v2 = rename_assumption_top_level(commit_to_least_complex_success_choice(dropped_proof))
                # print("proof tae v3 ", count_proof_failures(backtracking_proof))
                v3_input = "state_0:\n" + get_thm_initial_state(num_vars, prop) + "\n"
                v3_output = get_thm_proof_text_top_level(num_vars, prop, backtracking_proof_v2)
                with open(output_base_path + "v3_2.input.txt", "w") as f:
                    f.write(v3_input)
                with open(output_base_path + "v3_2.output.txt", "w") as f:
                    f.write(v3_output)
                with open(output_base_path +  "v3_2.json", "w") as f:
                    json.dump({"input": v3_input, "output": v3_output}, f)
    
if __name__ == "__main__":
    os.makedirs("data_5_vars", exist_ok=True)
    limit = 111163

    # if not os.path.exists("data_5_vars/_all_theorems.json"):
    #     unique_encodings : Set[int] = set()
    #     while len(unique_encodings) < limit:
    #         for i in tqdm(range((limit - len(unique_encodings)) * NON_PARALLEL_SUCCESS_RATE_MULTIPLIER)):
    #             candidate = random.randint(MIN_THEOREM_NUMBER, MAX_THEOREM_NUMBER) 
    #             if judge_encoding(candidate):
    #                 unique_encodings.add(candidate)
    #         # tqdm.update()

    #     unique_encodings = list(unique_encodings)[:limit]

    #     with open("data_5_vars/_all_theorems.json", "w") as f:
    #         json.dump(unique_encodings, f)  

    with open("data_5_vars/_all_theorems.json", "r") as f:
        unique_encodings = [int(i) for i in tqdm(json.load(f))]
                
    if len(unique_encodings) != limit:
        raise ValueError("The number of unique encodings is not equal to the limit", len(unique_encodings), limit)
    # with concurrent.futures.ProcessPoolExecutor(max_workers=NUM_WORKERS) as executor:
        # futures = [executor.submit(process_encoding, encoding) for encoding in unique_encodings]
        # for _ in tqdm(concurrent.futures.as_completed(futures), total=len(unique_encodings)):
        #     pass

        # list(tqdm(executor.map(process_encoding, unique_encodings, chunksize=CHUNK_SIZE), total=len(unique_encodings)))
    print("Start Concurrent Generation with ", NUM_WORKERS, " workers")
    with concurrent.futures.ThreadPoolExecutor(max_workers=NUM_WORKERS) as executor:
        list(tqdm(executor.map(create_v3_random_datapoint, unique_encodings, chunksize=CHUNK_SIZE), total=len(unique_encodings)))
    # for encoding in tqdm(unique_encodings):
    #     create_v3_random_datapoint(encoding)

    output_path_template = f"data_{NUM_VARS}_vars/"
    # with open(output_path_template + "_all_theorems.json", "r") as f:
    #     all_theorems = [int(i) for i in json.load(f)]

    all_theorems = unique_encodings
    
    v3 = {}
    v3_2 = {}
    for encoding in tqdm(all_theorems):
        path_template = get_output_base_path_from_encoding(encoding, NUM_VARS)
        v3[encoding] = []
        v3_2[encoding] = []
        for i in range(RANDOM_CHOICE_NUMBER):
            with open(path_template + f"{i}.v3.json", "r") as f:
                v3[encoding].append(json.load(f))
        for i in range(RANDOM_CHOICE_NUMBER):
            with open(path_template + f"{i}.v3_2.json", "r") as f:
                v3_2[encoding].append(json.load(f))
    
    with open(output_path_template + "_v3.json", "w") as f:
        json.dump(v3, f)
    with open(output_path_template + "_v3_2.json", "w") as f:
        json.dump(v3_2, f)

    # create zip file
    with zipfile.ZipFile(f"data_{NUM_VARS}_vars_{datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}.zip", 'w') as zf:
        zf.write(output_path_template + "_all_theorems.json")
        zf.write(output_path_template + "_v3.json")
        zf.write(output_path_template + "_v3_2.json")


    