from propositional_logic.random_gen.data import *



# def to_intuitionistic(p : Proposition) -> Proposition:
#     match p:
#         case Atom(name):
#             return p
#         case And(left, right):
#             return And(to_intuitionistic(left), to_intuitionistic(right))
#         case Or(left, right):
#             return Or(to_intuitionistic(left), to_intuitionistic(right))
#         case Implies(left, right):
#             return Implies(to_intuitionistic(left), to_intuitionistic(right))
#         case PTrue():
#             return p
#         case PFalse():
#             return p
#         case _:
#             raise ValueError(f"Invalid proposition: {p}")


def negative_polarize(atoms: Dict[str, Proposition], p : Proposition) -> Proposition:
    match p:
        case Atom(name):
            if name in atoms:
                if isinstance(atoms[name], NegAtom):
                    return atoms[name]
                else:
                    return Upshift(atoms[name])
            else:
                atoms[name] = NegAtom(name)
                return NegAtom(name)
        case And(left, right):
            return NegAnd(negative_polarize(atoms, left), negative_polarize(atoms, right))
        case Or(left, right):
            return Upshift(positive_polarize(atoms, p))
        case Implies(left, right):
            return Implies(positive_polarize(atoms, left), negative_polarize(atoms, right))
        case PTrue():
            return p
        case PFalse():
            return Upshift(positive_polarize(atoms, p))
        case _:
            raise ValueError(f"Invalid proposition: {p}")

def positive_polarize(atoms: Dict[str, Proposition], p : Proposition) -> Proposition:
    match p:
        case Atom(name):
            if name in atoms:
                if isinstance(atoms[name], PosAtom):
                    return atoms[name]
                else:
                    return Downshift(atoms[name])
            else:
                atoms[name] = PosAtom(name)
                return PosAtom(name)
        case And(left, right):
            return PosAnd(positive_polarize(atoms, left), positive_polarize(atoms, right))
        case Or(left, right):
            return Or(positive_polarize(atoms, left), positive_polarize(atoms, right))
        case Implies(left, right):
            return Downshift(negative_polarize(atoms, p))
        case PTrue():
            return p
        case PFalse():
            return p
        case _:
            raise ValueError(f"Invalid proposition: {p}")


def unpolarize(p: Proposition) -> Proposition:
    match p:
        case Atom(name):
            return p
        case And(left, right):
            return And(unpolarize(left), unpolarize(right))
        case Or(left, right):
            return Or(unpolarize(left), unpolarize(right))
        case Implies(left, right):
            return Implies(unpolarize(left), unpolarize(right))
        case PTrue():
            return p
        case PFalse():
            return p
        case PosAtom(name):
            return Atom(name)
        case NegAtom(name):
            return Atom(name)
        case PosAnd(left, right):
            return And(unpolarize(left), unpolarize(right))
        case NegAnd(left, right):
            return And(unpolarize(left), unpolarize(right))
        case Upshift(operand):
            return unpolarize(operand)
        case Downshift(operand):
            return unpolarize(operand)
        case _:
            raise ValueError(f"Invalid proposition: {p}")