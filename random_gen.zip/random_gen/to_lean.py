

from __future__ import annotations
from dataclasses import dataclass
import typing
from typing import *
import random
import z3
from propositional_logic.random_gen.data import *
from propositional_logic.random_gen.proof_construction import next_assump_name
import random
from propositional_logic.random_gen.theorem_encoding import *

lean_theorem_count = 0
do_not_show_cot = False

def get_chain_of_thought_for_proof_step(indent: str, proof: Proof) -> List[str]:
    """ Get one step chain of thoughts with newline"""
    if do_not_show_cot:
        return ["", "", ""]
    match proof:
        case ImpliesR((name, subproof)):
            return [f"{indent}-- Implications on the right can always be decomposed.\n"]
        case NegAndR(left, right):
            return [f"{indent}-- Conjunctions on the right can always be decomposed.\n"]
        case NegTrueR():
            return [f"{indent}-- True on the right can always be proven directly.\n"]
        case NegAtomR(subproof):
            return []
        case UpshiftR(subproof):
            return []
        case OrL(name, (left_name, left_proof), (right_name, right_proof)):
            return [f"{indent}-- Disjunctions on the left can always be decomposed.\n"]
        case FalseL(name):
            return [f"{indent}-- False on the left can always be used.\n"]
        case PosAndL(name, (left_name, right_name, subproof)):
            return [f"{indent}-- Conjunctions on the left can always be decomposed.\n"]
        case PosTrueL(name, subproof):
            return []
        case PosAtomL(name, subproof):
            return []
        case DownshiftL(name, subproof):
            return []
        case StableSeq(subproof):
            return []
        case FocusR(subproof):
            return []
        case FocusL(name, subproof):
            return []
        case OrR_left(subproof):
            return [f"{indent}-- Show the left disjunct based on <expert-advice>.\n"]
        case OrR_right(subproof):
            return [f"{indent}-- Show the right disjunct based on <expert-advice>.\n"]
        case PosAndR(left, right):
            return [f"{indent}-- Conjunctions on the right can always be decomposed.\n"]
        case PosTrueR():
            return [f"{indent}-- True on the right can always be proven directly.\n"]
        case PosAtomR(name):
            return [f"{indent}-- One of the premise coincides with the conclusion.\n"]
        case DownshiftR(subproof):
            return []
        case ImpliesL(name, prop, left, (right_name, right_proof), additional_name):
            return [f"{indent}-- We want to use the implication {name} based on <expert-advice>. So we show its premise.\n",
            f"{indent}-- We have shown the premise of {name}, we can now drive its conclusion.\n" ]
        case NegAndL_left(name, (left_name, left_proof)):
            return [f"{indent}-- We need to get the left conjuct of {name} based on <expert-advice>.\n"]
        case NegAndL_right(name, (right_name, right_proof)):
            return [f"{indent}-- We need to get the right conjuct of {name} based on <expert-advice>.\n"]
        case NegAtomL(name):
            return [f"{indent}-- One of the premise coincides with the conclusion.\n"]
        case UpshiftL(name, subproof):
            return []
        case _:
            raise ValueError(f"Invalid proof: {proof}")



def get_top_level_lean_tactics(indent: str, proof: Proof) -> List[str]:
    match proof:
        case ImpliesR((name, subproof)):
            return [f"{indent}intro {name}"]
        case NegAndR(left, right):
            return [f"{indent}apply And.intro"]
        case NegTrueR():
            return [f"{indent}apply True.intro"]
        case NegAtomR(subproof):
            return []
        case UpshiftR(subproof):
            return []
        case OrL(name, (left_name, left_proof), (right_name, right_proof)):
            return [f"{indent}cases {name}",
                   f"{indent}case inl {left_name} =>",
                     f"{indent}case inr {right_name} =>"]
        case FalseL(name):
            return [f"{indent}apply False.elim {name}"]
        case PosAndL(name, (left_name, right_name, subproof)):
            return [f"{indent}let {left_name} := {name}.left",
                   f"{indent}let {right_name} := {name}.right"]
        case PosTrueL(name, subproof):
            return []
        case PosAtomL(name, subproof):
            return []
        case DownshiftL(name, subproof):
            return []
        case StableSeq(subproof):
            return []
        case FocusR(subproof):
            return []
        case FocusL(name, subproof):
            return []
        case OrR_left(subproof):
            return [f"{indent}apply Or.inl"]
        case OrR_right(subproof):
            return [f"{indent}apply Or.inr"]
        case PosAndR(left, right):
            return [f"{indent}apply And.intro"]
        case PosTrueR():
            return [f"{indent}apply True.intro"]
        case PosAtomR(name):
            return [f"{indent}exact {name}"]
        case DownshiftR(subproof):
            return []
        case ImpliesL(name, prop, left, (right_name, right_proof), additional_name):
            return [f"{indent}have {additional_name} : {to_lean_theorem_text(prop)} := by",
                   f"{indent}let {right_name} := {name} {additional_name}"]
        case NegAndL_left(name, (left_name, left_proof)):
            return [f"{indent}let {left_name} := {name}.left"]
        case NegAndL_right(name, (right_name, right_proof)):
            return [f"{indent}let {right_name} := {name}.right"]
        case NegAtomL(name):
            return [f"{indent}exact {name}"]
        case UpshiftL(name, subproof):
            return []
        case ProofFailed():
            return []
        case FocusChoice(_):
            return []
        case NegAndL_choice(_, _):
            return []
        case OrR_choice(_, _):
            return []
        case _:
            raise ValueError(f"Invalid proof: {proof}")



def to_lean_proof(indent: str, proof: Proof) -> str:
    sub_indent = indent + "  "
    match proof:
        case ImpliesR((name, subproof)):
            return get_chain_of_thought_for_proof_step(indent, proof)[0] + \
                    get_top_level_lean_tactics(indent, proof)[0] + "\n" + \
                    to_lean_proof(indent, subproof)
        case NegAndR(left, right):
            return get_chain_of_thought_for_proof_step(indent, proof)[0] + \
                    get_top_level_lean_tactics(indent, proof)[0] + "\n" + \
                    to_lean_proof(indent, left) + "\n" + \
                    to_lean_proof(indent, right)
        case NegTrueR():
            return get_chain_of_thought_for_proof_step(indent, proof)[0] + \
                get_top_level_lean_tactics(indent, proof)[0] 
        case NegAtomR(subproof):
            return to_lean_proof(indent, subproof)
        case UpshiftR(subproof):
            return to_lean_proof(indent, subproof)
        case OrL(name, (left_name, left_proof), (right_name, right_proof)):
            return get_chain_of_thought_for_proof_step(indent, proof)[0] + \
                    get_top_level_lean_tactics(indent, proof)[0] + "\n" + \
                    get_top_level_lean_tactics(indent, proof)[1] + "\n" + \
                    to_lean_proof(sub_indent, left_proof) + "\n" + \
                    get_top_level_lean_tactics(indent, proof)[2] + "\n" + \
                    to_lean_proof(sub_indent, right_proof)
        case FalseL(name):
            return get_chain_of_thought_for_proof_step(indent, proof)[0] + \
                get_top_level_lean_tactics(indent, proof)[0] 
        case PosAndL(name, (left_name, right_name, subproof)):
            return get_chain_of_thought_for_proof_step(indent, proof)[0] + \
                get_top_level_lean_tactics(indent, proof)[0] + "\n" + \
                get_top_level_lean_tactics(indent, proof)[1] + "\n" + \
                to_lean_proof(indent, subproof)
        case PosTrueL(name, subproof):
            return to_lean_proof(indent, subproof)
        case PosAtomL(name, subproof):
            return to_lean_proof(indent, subproof)
        case DownshiftL(name, subproof):
            return to_lean_proof(indent, subproof)
        case StableSeq(subproof):
            return to_lean_proof(indent, subproof)
        case FocusR(subproof):
            return to_lean_proof(indent, subproof)
        case FocusL(name, subproof):
            return to_lean_proof(indent, subproof)
        case OrR_left(subproof):
            return get_chain_of_thought_for_proof_step(indent, proof)[0] + \
                    get_top_level_lean_tactics(indent, proof)[0] + "\n" + \
                    to_lean_proof(indent, subproof)
        case OrR_right(subproof):
            return get_chain_of_thought_for_proof_step(indent, proof)[0] + \
                    get_top_level_lean_tactics(indent, proof)[0] + "\n" + \
                    to_lean_proof(indent, subproof)
        case PosAndR(left, right):
            return get_chain_of_thought_for_proof_step(indent, proof)[0] + \
                get_top_level_lean_tactics(indent, proof)[0] + "\n" + \
                to_lean_proof(indent, left) + "\n" + \
                to_lean_proof(indent, right)
        case PosTrueR():
            return get_chain_of_thought_for_proof_step(indent, proof)[0] + \
                get_top_level_lean_tactics(indent, proof)[0]
        case PosAtomR(name):
            return get_chain_of_thought_for_proof_step(indent, proof)[0] + \
                get_top_level_lean_tactics(indent, proof)[0]
        case DownshiftR(subproof):
            return to_lean_proof(indent, subproof)
        case ImpliesL(name, prop, left, (right_name, right_proof), additional_name):
            return get_chain_of_thought_for_proof_step(indent, proof)[0] + \
                    get_top_level_lean_tactics(indent, proof)[0] + "\n" + \
                    to_lean_proof(sub_indent, left) + "\n" + \
                    get_chain_of_thought_for_proof_step(indent, proof)[1] + \
                    get_top_level_lean_tactics(indent, proof)[1] + "\n" + \
                    to_lean_proof(indent, right_proof)
        case NegAndL_left(name, (left_name, left_proof)):
            return get_chain_of_thought_for_proof_step(indent, proof)[0] + \
                get_top_level_lean_tactics(indent, proof)[0] + "\n" + \
                to_lean_proof(indent, left_proof)
        case NegAndL_right(name, (right_name, right_proof)):
            return get_chain_of_thought_for_proof_step(indent, proof)[0] + \
                get_top_level_lean_tactics(indent, proof)[0] + "\n" + \
                to_lean_proof(indent, right_proof)
        case NegAtomL(name):
            return get_chain_of_thought_for_proof_step(indent, proof)[0] + \
                get_top_level_lean_tactics(indent, proof)[0]
        case UpshiftL(name, subproof):
            return to_lean_proof(indent, subproof)
        case ProofFailed():
            return ""
        case _:
            raise ValueError(f"Invalid proof: {proof}")







        
def to_lean_theorem_text(p : Proposition):
        match p:
            case Atom(name):
                return name
            case PosAtom(name):
                return name
            case NegAtom(name):
                return name
            case And(left, right):
                return f"({to_lean_theorem_text(left)} ∧ {to_lean_theorem_text(right)})"
            case PosAnd(left, right):
                return f"({to_lean_theorem_text(left)} ∧ {to_lean_theorem_text(right)})"
            case NegAnd(left, right):
                return f"({to_lean_theorem_text(left)} ∧ {to_lean_theorem_text(right)})"
            case Or(left, right):
                return f"({to_lean_theorem_text(left)} ∨ {to_lean_theorem_text(right)})"
            case Implies(left, right):
                return f"({to_lean_theorem_text(left)} → {to_lean_theorem_text(right)})"
            case PTrue():
                return "True"
            case PFalse():
                return "False"
            case Downshift(operand):
                return to_lean_theorem_text(operand)
            case Upshift(operand):
                return to_lean_theorem_text(operand)
            case _:
                raise ValueError(f"Invalid proposition: {p}")
        
        


def to_lean_theorem_and_proof(num_vars : int, expr: Proposition, proof: Proof) -> str:
    
    theorem_text = to_lean_theorem_only(num_vars, expr)
    proof_text = to_lean_proof('  ', proof) + "\n"

    return theorem_text + proof_text
    

def to_lean_theorem_only(num_vars : int, expr: Proposition) -> str:
    # global lean_theorem_count
    # # Create a dictionary to map Atom names to Z3 variables
    # lean_theorem_count += 1
    # this_random = random.randint(10000, 99999)
    # free_vars = list(set(freeVars(expr)))
    vars_decl = f"variable ({' '.join(f'p{i+1}' for i in range(num_vars))} : Prop)\n" 
    
    theorem_text = f"theorem thm_{num_vars}_vars_{encode_prop(expr, num_vars)} : {to_lean_theorem_text(expr)} := by\n"

    return vars_decl + theorem_text