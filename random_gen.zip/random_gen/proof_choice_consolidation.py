
from propositional_logic.random_gen.data import *


def collect_top_level_choices(p: Proof) -> Sequence[Proof]:
    match p:
        case FocusChoice(choices):
            all_choices : List[Proof] = []
            for c in choices:
                all_choices.extend(collect_top_level_choices(c))
            return all_choices
        case NegAndL_choice(l, r):
            return [l, r]
        case OrR_choice(l, r):
            return [l, r]
        case FocusR(sub):
            return collect_top_level_choices(sub)
        case FocusL(name, sub):
            return collect_top_level_choices(sub)
        case ProofFailed():
            return []
        case _:
            return [p]

        
def refine_choice(proof: Proof) -> Proof:
    def consolidate_proof_choice(proof: Proof) -> Optional[Proof]:
        match proof:
            case FocusChoice(choices):
                all_choices = collect_top_level_choices(proof)
                refined = [refine_choice(c) for c in all_choices]
                return FocusChoice(refined)
            case _:
                return None
    return map_proof(consolidate_proof_choice, proof)
