import json
from collections import Counter
if __name__ == "__main__":
    nodes = json.load(open("data_5_vars/_internal_nodes.json", "r"))
    print( Counter(nodes.values()))
