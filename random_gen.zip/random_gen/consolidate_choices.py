
from propositional_logic.random_gen.data import *
from propositional_logic.random_gen.proof_fail_check import *
from propositional_logic.random_gen.proof_complexity import *

def shuffle_choices(p: Proof) -> Proof:
    def make_choice(p: Proof) -> Optional[Proof]:
        match p:
            case FocusChoice(choices):
                return FocusChoice(random.sample([shuffle_choices(c) for c in choices], len(choices)))
            case NegAndL_choice(l, r):
                return NegAndL_choice(*random.sample([shuffle_choices(l), shuffle_choices(r)], 2))
            case OrR_choice(l, r):
                return OrR_choice(*random.sample([shuffle_choices(l), shuffle_choices(r)], 2))
            case _:
                return None
    return map_proof(make_choice, p)

def commit_to_first_success_choice(p: Proof) -> Proof:
    def make_choice(p: Proof) -> Optional[Proof]:
        match p:
            case FocusChoice(choices):
                for c in choices:
                    if not proof_has_failed(c):
                        return commit_to_first_success_choice(c)
                else:
                    raise ValueError("No non-failing choices")
            case NegAndL_choice(l, r):
                if not proof_has_failed(l):
                    return commit_to_first_success_choice(l)
                elif not proof_has_failed(r):
                    return commit_to_first_success_choice(r)
                else:
                    raise ValueError("Both choices failed")
            case OrR_choice(l, r):
                if not proof_has_failed(l):
                    return commit_to_first_success_choice(l)
                elif not proof_has_failed(r):
                    return commit_to_first_success_choice(r)
                else:
                    raise ValueError("Both choices failed")
            case _:
                return None
    return map_proof(make_choice, p)


    
def commit_to_least_complex_success_choice(p: Proof) -> Proof:
    def make_choice(p: Proof) -> Optional[Proof]:
        match p:
            case FocusChoice(choices):
                success_choices = [commit_to_least_complex_success_choice(c) for c in choices if not proof_has_failed(c)]
                return commit_to_least_complex_success_choice(min(success_choices, key=calculate_complexity))
            case NegAndL_choice(l, r):
                success_choices = [commit_to_least_complex_success_choice(c) for c in [l, r] if not proof_has_failed(c)]
                return commit_to_least_complex_success_choice(min(success_choices, key=calculate_complexity))
            case OrR_choice(l, r):
                success_choices = [commit_to_least_complex_success_choice(c) for c in [l, r] if not proof_has_failed(c)]
                return commit_to_least_complex_success_choice(min(success_choices, key=calculate_complexity))
            case _:
                return None
    return map_proof(make_choice, p)


def commit_drop_additional_choices_after_first_success(p: Proof) -> Proof:
    # print("commit_drop_additional_choices_after_first_success", p)
    def make_choice(p: Proof) -> Optional[Proof]:
        match p:
            case FocusChoice(choices):
                new_choices = []
                for c in choices:
                    if not proof_has_failed(c):
                        new_choices.append(commit_drop_additional_choices_after_first_success(c))
                        break
                    else:
                        new_choices.append(commit_drop_additional_choices_after_first_success(c))
                return FocusChoice(new_choices)
            case NegAndL_choice(l, r):
                if not proof_has_failed(l):
                    return commit_drop_additional_choices_after_first_success(l)
                else:
                    return NegAndL_choice(
                        commit_drop_additional_choices_after_first_success(l),
                        commit_drop_additional_choices_after_first_success(r)
                    )
            case OrR_choice(l, r):
                if not proof_has_failed(l):
                    return commit_drop_additional_choices_after_first_success(l)
                else:
                    return OrR_choice(
                        commit_drop_additional_choices_after_first_success(l),
                        commit_drop_additional_choices_after_first_success(r)
                    )
                # else:
                #     raise ValueError("Both choices failed")
            case _:
                return None
    result =  map_proof(make_choice, p)    
    return result
