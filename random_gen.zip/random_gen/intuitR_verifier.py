
import json
import subprocess

import os


from propositional_logic.random_gen.data import *
from propositional_logic.random_gen.theorem_encoding import *



home_folder = os.path.expanduser("~")


temp_folder = "./.intuitR.data"
os.makedirs(temp_folder, exist_ok=True)

def prop_to_tptp_fmt(prop: Proposition) -> str:
    match prop:
        case PTrue():
            return "$true"
        case PFalse():
            return "$false"
        case Atom(name):
            return name
        case And(p1, p2):
            return f"({prop_to_tptp_fmt(p1)} & {prop_to_tptp_fmt(p2)})"
        case Or(p1, p2):
            return f"({prop_to_tptp_fmt(p1)} | {prop_to_tptp_fmt(p2)})"
        case Implies(p1, p2):
            return f"({prop_to_tptp_fmt(p1)} => {prop_to_tptp_fmt(p2)})"
        case _:
            raise ValueError(f"Cannot convert {prop} to TPTP format")



def check_prop_intuit_valid(id: int, num_vars: int) -> bool:
    prop = decode_prop(id, num_vars)
    fname = os.path.join(temp_folder, "vars_"+ str(num_vars) + "_" + str(id) + ".p")
    with open(fname, "w") as f:
        f.write("fof(thm,conjecture,(" + prop_to_tptp_fmt(prop) + ")).")

    intuitR_exec_path = os.path.join(home_folder, ".cabal", "bin", "intuitR")
    # Run the Lean REPL as a subprocess
    process = subprocess.Popen([intuitR_exec_path, fname], 
                               stdin=subprocess.PIPE, 
                               stdout=subprocess.PIPE, 
                               stderr=subprocess.PIPE, 
                               text=True)
    
    stdout, stderr = process.communicate()

    if "RESULT: CounterSatisfiable (intuitionistically)" in stdout:
        return False
    elif "RESULT: Valid (intuitionistically)" in stdout:
        return True
    else:
        raise ValueError(f"Unexpected output from Intuit: {stdout, stderr}")
