import json
import statistics

if __name__ == "__main__":
    # Open the JSON file
    with open("v2_v3_2_5_vars_stat.json") as f:
        data = json.load(f)

    # Extract variables
    v2_length = data.get("v2_length", [])
    v3_2_length = data.get("v3_2_length", [])
    v3_2_more = data.get("v3_2_more", [])

    # Calculate statistics
    v2_avg = statistics.mean(v2_length)
    v2_std_dev = statistics.stdev(v2_length)

    v3_2_avg = statistics.mean(v3_2_length)
    v3_2_std_dev = statistics.stdev(v3_2_length)

    v3_2_more_avg = statistics.mean(v3_2_more)
    v3_2_more_std_dev = statistics.stdev(v3_2_more)

    # Print results
    print(f"Statistics for v2_length: Average = {v2_avg}, Standard Deviation = {v2_std_dev}")
    print(f"Statistics for v3_2_length: Average = {v3_2_avg}, Standard Deviation = {v3_2_std_dev}")
    print(f"Statistics for v3_2_more: Average = {v3_2_more_avg}, Standard Deviation = {v3_2_more_std_dev}")
