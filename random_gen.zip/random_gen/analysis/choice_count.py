
from ..theorem_encoding import *
from ..consolidate_choices import *
from ..proof_construction import *
from ..data import *
import random
import statistics

choice_counts = []

        
def stat_choice(proof: Proof) -> Proof:
    def consolidate_proof_choice(proof: Proof) -> Optional[Proof]:
        match proof:
            case FocusChoice(choices):
                if len(choices) > 0:
                    choice_counts.append(len(choices))
                return None
            case _:
                return None
    return map_proof(consolidate_proof_choice, proof)

for i in range(1000):
    proof = construct_proof_top_level(decode_prop(random.randint(0, 10 ** 30), 5))
    while proof_has_failed(proof):
        proof = construct_proof_top_level(decode_prop(random.randint(0, 10 ** 30), 5))
    stat_choice(proof)

print(choice_counts)
print("mean", statistics.mean(choice_counts))
print("median", statistics.median(choice_counts))
print("stddev", statistics.stdev(choice_counts))