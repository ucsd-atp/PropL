
import json
from ..theorem_encoding import *
from tqdm import tqdm
import os

def get_output_base_path(prop: Proposition, encoding: int, num_vars : int) -> str:
    return f"data_{num_vars}_vars/thm_{num_vars}_vars_{count_internal_nodes(prop)}_nodes_{encoding}."

if __name__ == "__main__":
    with open("data_5_vars/_all_theorems.json", "r") as f:
        all_encodings = json.load(f)
    ok_encodings = []
    for encoding in tqdm(all_encodings):
        output_base = get_output_base_path(decode_prop(encoding, 5), encoding, 5)
        if os.path.exists(output_base + "v3_2.output.txt") and os.path.exists(output_base + "v2.output.txt"):
            ok_encodings.append(encoding)
    v2_length = []
    v3_2_length = []
    v3_2_more = []
    for encoding in tqdm(ok_encodings):
        output_base = get_output_base_path(decode_prop(encoding, 5), encoding, 5)
        with open(output_base + "v2.output.txt", "r") as f:
            v2 = len(f.read().split())
        with open(output_base + "v3_2.output.txt", "r") as f:
            v3_2 = len(f.read().split())
        diff = v3_2 - v2
        v2_length.append(v2)
        v3_2_length.append(v3_2)
        v3_2_more.append(diff)
        # tqdm.write(f"{encoding} {v2} {v3_2} DIFF: {diff}\n")
    
    with open("v2_v3_2_5_vars_stat.json", "w") as f:
        json.dump({"v2_length": v2_length, "v3_2_length": v3_2_length, "v3_2_more": v3_2_more}, f)
        
    
        

        
            

    
    