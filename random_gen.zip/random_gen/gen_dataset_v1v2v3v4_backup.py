

import os
from propositional_logic.random_gen.theorem_encoding import *
from propositional_logic.random_gen.proof_construction import *
from propositional_logic.random_gen.proof_fail_check import *
from propositional_logic.random_gen.to_lean import *
from propositional_logic.random_gen.consolidate_choices import *
from propositional_logic.random_gen.assumption_renaming import *
from propositional_logic.random_gen.to_training import *
from propositional_logic.random_gen.proof_complexity import *
from propositional_logic.random_gen.gen_failure_tracing import *



def get_output_base_path(prop: Proposition, encoding: int, num_vars : int) -> str:
    return f"data_{num_vars}_vars/thm_{num_vars}_vars_{count_internal_nodes(prop)}_nodes_{encoding}."

def get_output_base_path_from_encoding(encoding: int, num_vars : int) -> str:
    prop = decode_prop(encoding, num_vars)
    return get_output_base_path(prop, encoding, num_vars)

def check_provable(encoding: int, num_vars: int, min_complexity : int = -1) -> bool:
    """
    Minimum complexity ensures that the proof is at least this complex
    """
    prop = decode_prop(encoding, num_vars)
    proof = construct_proof_top_level(prop)
    if proof_has_failed(proof):
        return False
    elif calculate_complexity(proof) < min_complexity:
        return False
    else:
        return True

def check_contains_implication_only(prop: Proposition) -> bool:
    match prop:
        case Implies(l, r):
            return check_contains_implication_only(l) and check_contains_implication_only(r)
        case Atom(_):
            return True
        case And(_, _) | Or(_, _) | PTrue() | PFalse():
            return False
        case _:
            raise ValueError("Unexpected proposition", prop)

def check_prop_worth_pursuing(encoding: int, num_vars: int, min_fails, max_fails) -> bool:
    prop = decode_prop(encoding, num_vars)
    proof = construct_proof_top_level(prop)

    if proof_has_failed(proof):
        return False
    else:
        proof = commit_drop_additional_choices_after_first_success(proof)
        if min_fails <= count_proof_failures(proof) <= max_fails:
            return True
        else:
            return False



def create_datapoint(encoding: int, num_vars: int) -> None:
    os.makedirs(f"data_{num_vars}_vars", exist_ok=True)
    prop = decode_prop(encoding, num_vars)
    proof = construct_proof_top_level(prop)
    # print("proof tae start ", count_proof_failures(proof))


    if proof_has_failed(proof):
        print("WARNING: proof has failed for", encoding, num_vars)
        return
        # raise ValueError("Proof has failed, cannot create a datapoin for failed proofs", prop, proof)

    output_base_path = get_output_base_path(prop, encoding, num_vars)
    # v1
    lean_proof = rename_assumption_top_level(commit_to_least_complex_success_choice(proof))
    if not os.path.exists(output_base_path + "v1.lean"):
        lean_text = to_lean_theorem_and_proof(num_vars, prop, lean_proof)
        with open(output_base_path + "v1.lean", "w") as f:
            f.write(lean_text)

    # v2
    if not os.path.exists(output_base_path + "v2.json"):
        with open(output_base_path+ "v2.input.txt", "w") as f:
            v2_input = "state_0:\n" + get_thm_initial_state(num_vars, prop) + "\n"
            f.write(v2_input)
        with open(output_base_path + "v2.output.txt", "w") as f:
            v2_output = get_thm_proof_text_top_level(num_vars, prop, lean_proof)
            f.write(v2_output)
        with open(output_base_path +  "v2.json", "w") as f:
            json.dump({"input": v2_input, "output": v2_output}, f)

    # v3
    if not os.path.exists(output_base_path + "v3.json"):
        backtracking_proof = rename_assumption_top_level(commit_drop_additional_choices_after_first_success(proof))
        # print("proof tae v3 ", count_proof_failures(backtracking_proof))
        v3_input = "state_0:\n" + get_thm_initial_state(num_vars, prop) + "\n"
        v3_output = get_thm_proof_text_top_level(num_vars, prop, backtracking_proof)
        with open(output_base_path + "v3.input.txt", "w") as f:
            f.write(v3_input)
        with open(output_base_path + "v3.output.txt", "w") as f:
            f.write(v3_output)
        with open(output_base_path +  "v3.json", "w") as f:
            json.dump({"input": v3_input, "output": v3_output}, f)

    #v4
    if not os.path.exists(output_base_path + "v4.json"):
        v4_num = trace_split_failure_top_level(output_base_path)
        with open(output_base_path + "v4.json", "w") as f:
            json.dump({"completed": v4_num}, f)
        for i in range(v4_num):
            with open(output_base_path + f"v4.{i+1}.input.txt", "r") as f:
                input = f.read() 
            with open(output_base_path + f"v4.{i+1}.output.txt", "r") as f:
                output = f.read()
            with open(output_base_path + f"v4.{i+1}.json", "w") as f:
                json.dump({"input": input, "output": output}, f)
    



if __name__ == "__main__":
    create_datapoint(0, 5)
    create_datapoint(10**20, 5)