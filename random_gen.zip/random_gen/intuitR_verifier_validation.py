

from propositional_logic.random_gen.data import *
from propositional_logic.random_gen.theorem_encoding import *
from propositional_logic.random_gen.proof_construction import *
from propositional_logic.random_gen.proof_fail_check import *
from propositional_logic.random_gen.intuitR_verifier import *
from tqdm import tqdm

f_incomplete = open("incomplete_theorems.txt", "w+")


def validate_single_id(encoding: int, num_vars: int) -> bool:
    prop = decode_prop(encoding, num_vars)
    proof = construct_proof_top_level(prop)


    we_have_proof = not proof_has_failed(proof)
    ir_has_proof = check_prop_intuit_valid(encoding, num_vars)
    if we_have_proof != ir_has_proof:
        f_incomplete.write((f"we_have_proof: {we_have_proof}, ir_has_proof: {ir_has_proof} {encoding} {num_vars}\n"))
        f_incomplete.flush()
        return False
    else:
        return True


print("implications only validation: (complete algorithm should all return true)", 
      list(validate_single_id(enc, 5) for enc in [ 47786
            , 48417 , 49048 , 49679 , 50430 , 51692
            , 52323 , 52954 , 53705 , 54336 , 55598
            , 56229 , 56980 , 57611 , 58242 , 59504
            , 60255 , 60886 , 61517 , 62148]))


num_failed = 0
num_tests = 100000
for i in tqdm(range(100000)):
    encoding = random.randint(0, 10 ** 5)
    num_vars = 5
    if not validate_single_id(encoding, num_vars):
        num_failed += 1
        tqdm.write(f"num_failed: {num_failed}, total: {i}")

