from .gen_failure_tracing import *
from .data import *
from .theorem_encoding import *
from .proof_construction import *
from .proof_choice_consolidation import *
from .consolidate_choices import *
from .assumption_renaming import *
from .to_training import *
import os


if __name__ == "__main__":
    base_path = "temp_v4_testing."
    if os.path.exists(base_path + "v3.output.txt"):
        with open(base_path +"v3.output.txt", "r") as f:
            v3_output = f.read()
    else:
    # if True:
        prop = decode_prop(180763909656481931037272967184, NUM_VARS)
        proof = construct_proof_top_level(prop)
        backtracking_proof = rename_assumption_top_level(commit_drop_additional_choices_after_first_success(proof))
        v3_output = get_thm_proof_text_top_level(NUM_VARS, prop, backtracking_proof)
        v3_input = "state_0:\n" + get_thm_initial_state(NUM_VARS, prop) + "\n"
        with open(base_path + "v3.input.txt", "w") as f:
            f.write(v3_input)
        with open(base_path + "v3.output.txt", "w") as f:
            f.write(v3_output)

    v4_output = trace_split_failure_top_level(base_path)

