

from propositional_logic.random_gen import data as e
from propositional_logic.random_gen.data import *

def calculate_complexity(p: e.Proof) -> int:
    match p:
        case ImpliesR((name, subproof)):
            return 1 + calculate_complexity(subproof)
        case NegAndR(left, right):
            return 1 + calculate_complexity(left) + calculate_complexity(right)
        case NegTrueR():
            return 1
        case NegAtomR(subproof):
            return 1 + calculate_complexity(subproof)
        case UpshiftR(subproof):
            return 1 + calculate_complexity(subproof)
        case OrL(name, (left_name, left_proof), (right_name, right_proof)):
            return 1 + calculate_complexity(left_proof) + calculate_complexity(right_proof)
        case FalseL(name):
            return 1
        case PosAndL(name, (left_name, right_name, subproof)):
            return 1 + calculate_complexity(subproof)
        case PosTrueL(name, subproof):
            return 1 + calculate_complexity(subproof)
        case PosAtomL(name, subproof):
            return 1 + calculate_complexity(subproof)
        case DownshiftL(name, subproof):
            return 1 + calculate_complexity(subproof)
        case StableSeq(subproof):
            return 1 + calculate_complexity(subproof)
        case FocusR(subproof):
            return 1 + calculate_complexity(subproof)
        case FocusL(name, subproof):
            return 1 + calculate_complexity(subproof)
        case OrR_left(subproof):
            return 1 + calculate_complexity(subproof)
        case OrR_right(subproof):
            return 1 + calculate_complexity(subproof)
        case PosAndR(left, right):
            return 1 + calculate_complexity(left) + calculate_complexity(right)
        case PosTrueR():
            return 1
        case PosAtomR(name):
            return 1
        case DownshiftR(subproof):
            return 1 + calculate_complexity(subproof)
        case ImpliesL(name, prop, left, (right_name, right_proof), additional_name):
            return 1 + calculate_complexity(left) + calculate_complexity(right_proof)
        case NegAndL_left(name, (left_name, left_proof)):
            return 1 + calculate_complexity(left_proof)
        case NegAndL_right(name, (right_name, right_proof)):
            return 1 + calculate_complexity(right_proof)
        case NegAtomL(name):
            return 1
        case UpshiftL(name, subproof):
            return 1 + calculate_complexity(subproof)
        case FocusChoice(choices):
            return 1 + sum([calculate_complexity(c) for c in choices])
        case OrR_choice(l, r):
            return 1 + calculate_complexity(l) + calculate_complexity(r)
        case NegAndL_choice(l, r):
            return 1 + calculate_complexity(l) + calculate_complexity(r)
        case ProofFailed():
            return 1
        case _:
            raise ValueError(f"Invalid proof: {p}")

