
from propositional_logic.random_gen.data import *
from propositional_logic.random_gen.to_lean import *
from propositional_logic.random_gen.get_lean_tactic_state import *
from propositional_logic.random_gen.proof_fail_check import *

class StateTrackingCtx:
    def __init__(self, num_vars: int, prop: Proposition, 
                 initial_indent:str = "  "):
        self.num_vars = num_vars
        self.prop = prop
        # self.proof = proof
        lean_text = to_lean_theorem_only(num_vars, prop)
        self.states = [lean_text]
        self.cur_state_num = 0
        self.current_indent = initial_indent
        self.result_buffer : List[str] = []
        self.state_current_choices : Dict[int, int] = {}

    def push_state(self, state: str) -> None:
        """State should be a partial lean proof"""
        self.states.append(state)
        self.cur_state_num = len(self.states) - 1

    def get_cur_state_num(self) -> int:
        return self.cur_state_num

    def set_cur_state_num(self, num: int) -> None:
        self.cur_state_num = num

    def get_cur_state_text(self) -> str:
        return self.states[self.cur_state_num]

    def increment_indent(self) -> None:
        self.current_indent += "  "
    
    def decrement_indent(self) -> None:
        self.current_indent = self.current_indent[:-2]
    
    def get_cur_tactic_state(self) -> str:
        return get_lean_tactic_state(self.get_cur_state_text() + "\n" + self.current_indent + "sorry")

    def get_previous_tacic_state(self, state_num: int, indentation: str) -> str:
        return get_lean_tactic_state(self.states[state_num] + "\n" + indentation + "sorry")


class TacticContext:
    """ State tracking context with smart indentation tracking, back tracking etc."""

    def __init__(self, num_vars: int, encoding: int):
        prop = decode_prop(encoding, num_vars)
        self.prop = prop
        self.ctx = StateTrackingCtx(num_vars, prop)
        self.indentations = [self.ctx.current_indent]
        self.prev_state_nums = {0: None}
    
    def push_new_state_with_tactic(self, tactic: str) -> None:
        """State should be a partial lean proof"""
        prev_state_num = self.ctx.get_cur_state_num()
        self.ctx.push_state(self.ctx.get_cur_state_text() + "\n" + self.ctx.current_indent + tactic)
        self.prev_state_nums[self.ctx.get_cur_state_num()] = prev_state_num
        if (tactic.startswith("have") and tactic.endswith("by")) \
            or (tactic.startswith("case") and tactic.endswith("=>")):
            self.ctx.increment_indent()
        self.indentations.append(self.ctx.current_indent)

    def copy_state_and_decrement_indent(self) -> None:
        """State should be a partial lean proof"""
        prev_state_num = self.ctx.get_cur_state_num()
        self.ctx.push_state(self.ctx.get_cur_state_text())
        self.prev_state_nums[self.ctx.get_cur_state_num()] = prev_state_num
        self.ctx.decrement_indent()
        self.indentations.append(self.ctx.current_indent)

    def is_at_the_top_level(self) -> bool:
        return self.indentations[self.ctx.get_cur_state_num()] == "  "
    
    def get_cur_tactic_state(self) -> str:
        return self.ctx.get_cur_tactic_state()

    def get_prev_tactic_state(self) -> str:
        prev_state_num = self.prev_state_nums[self.ctx.get_cur_state_num()]
        if prev_state_num is None:
            return None
        return self.ctx.get_previous_tacic_state(prev_state_num, self.indentations[prev_state_num])
    
    def back_track_to_state_num(self, to_state_num: int) -> None:
        self.ctx.set_cur_state_num(to_state_num)
        self.ctx.current_indent = self.indentations[to_state_num]

    def get_current_lean_proof(self):
        return self.ctx.get_cur_state_text()
    
    def get_cur_state_num(self):
        return self.ctx.get_cur_state_num()

    def get_prev_state_num(self):
        return self.prev_state_nums[self.ctx.get_cur_state_num()]

    def undo_last_push_new_state_with_tactic(self, state_num : int):
        """ 
        Roll back the effect of copy_state_and_decrement_indent, may only be called 
        immediately after copy_state_and_decrement_indent with no other operations in between.
        """
        assert state_num == self.ctx.get_cur_state_num()
        assert len(self.indentations) == state_num + 1
        assert len(self.ctx.states) == state_num + 1
        prev_state_num = self.prev_state_nums[state_num]
        self.ctx.set_cur_state_num(prev_state_num)
        self.ctx.current_indent = self.indentations[prev_state_num]
        self.indentations.pop()
        self.ctx.states.pop()
