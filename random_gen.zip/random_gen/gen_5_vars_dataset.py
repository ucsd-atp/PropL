

from propositional_logic.random_gen.gen_dataset import *
from propositional_logic.random_gen.theorem_encoding import *
from propositional_logic.random_gen.data import *
from tqdm import tqdm
import os
import concurrent.futures
from propositional_logic.random_gen.package_data import *
from propositional_logic.random_gen.params import *


def process_encoding(encoding:int):
    create_datapoint(encoding, NUM_VARS)

def judge_encoding(encoding:int) -> bool:
    return check_prop_worth_pursuing(encoding, NUM_VARS)
            # while ((not check_prop_worth_pursuing(encoding, 5, 5)) 
            #         or encoding in unique_encodings):
            #     encoding = random.randint(0, 10 ** 30)

def parallel_gen():
    os.makedirs("data_5_vars", exist_ok=True)
    if os.path.exists("exclude/_all_theorems.json"):
        with open("exclude/_all_theorems.json", "r") as f:
            excluding = set(json.load(f))
        print("exclusion loaded")
    else:
        excluding = set()




    TOTAL_LIMIT = 450000

    if not os.path.exists("data_5_vars/_all_theorems.json"):
        NUM_INTERNAL_NODES_LOWER = 16
        NUM_INTERNAL_NODES_UPPER = 40
        for i in range(NUM_INTERNAL_NODES_LOWER, NUM_INTERNAL_NODES_UPPER+1):
            num_successes = 0
            num_total = 0
            if os.path.exists(f"data_5_vars/_all_theorems_{i}.json"):
                continue
            current_encoding = []
            limit = 210000 if i == NUM_INTERNAL_NODES_LOWER else 10000
            while len(current_encoding) < limit:
                min_thm_number = cumulative_number_props_with_n_internal_nodes(i-1, NUM_VARS)
                max_thm_number = cumulative_number_props_with_n_internal_nodes(i, NUM_VARS) - 1

                print(f"current_encoding: {len(current_encoding)} / {limit}, num_successes: {num_successes}, num_total: {num_total}")
                def add_new_encodings(size):
                    nonlocal num_successes, num_total
                    encodings_to_check = [random.randint(min_thm_number, max_thm_number) 
                                            for i in tqdm(range(size)) if i not in excluding]
                    with concurrent.futures.ProcessPoolExecutor(max_workers=NUM_WORKERS) as executor:
                        # checked = executor.map(judge_encoding, tqdm(current_encoding))
                        checked = list(tqdm(executor.map(judge_encoding, encodings_to_check, chunksize=CHUNK_SIZE), total=len(encodings_to_check)))

                    
                    new_encodings = {encoding for encoding, valid in zip(encodings_to_check, checked) if valid}
                    current_encoding.extend(new_encodings)

                    num_successes += len(new_encodings)
                    num_total += size


                if num_total == 0:
                    next_checking_size = (limit - len(current_encoding))* PARALLEL_SUCCESS_RATE_MULTIPLIER
                elif num_successes == 0:
                    next_checking_size = next_checking_size * PARALLEL_SUCCESS_RATE_MULTIPLIER # this is exponential
                else:
                    # do not grow this number too much
                    proposed_checking_size = int (((num_total / num_successes) * (limit - len(current_encoding))))
                    if proposed_checking_size > next_checking_size * PARALLEL_SUCCESS_RATE_MULTIPLIER:
                        next_checking_size = next_checking_size * PARALLEL_SUCCESS_RATE_MULTIPLIER
                    else:
                        next_checking_size = proposed_checking_size
                    if next_checking_size > 10 ** 6:
                        next_checking_size = 10 ** 6
                add_new_encodings(next_checking_size)

            current_encoding = list(current_encoding)[:limit]
            with open(f"data_5_vars/_all_theorems_{i}.json", "w") as f:
                json.dump(list(current_encoding), f)  

        unique_encodings = []
        for i in range(NUM_INTERNAL_NODES_LOWER, NUM_INTERNAL_NODES_UPPER+1):
            with open(f"data_5_vars/_all_theorems_{i}.json", "r") as f:
                unique_encodings.extend(json.load(f))

        with open("data_5_vars/_all_theorems.json", "w") as f:
            json.dump(unique_encodings, f)  

    with open("data_5_vars/_all_theorems.json", "r") as f:
        unique_encodings = set(json.load(f))

        with concurrent.futures.ProcessPoolExecutor(max_workers=NUM_WORKERS) as executor:
            # checked = executor.map(judge_encoding, tqdm(unique_encodings))
            checked = list(tqdm(executor.map(judge_encoding, unique_encodings, chunksize=CHUNK_SIZE), total=len(unique_encodings)))
        if not all(checked):
            raise ValueError("Some encodings are not worth pursuing, please delete _all_theorems.json and try again", 
                            "success", len([c for c in checked if c]), "total" , len(checked))

    assert len(set(unique_encodings)) == len(unique_encodings)
    assert len(unique_encodings) == TOTAL_LIMIT
                
    with concurrent.futures.ProcessPoolExecutor(max_workers=NUM_WORKERS) as executor:
        # futures = [executor.submit(process_encoding, encoding) for encoding in unique_encodings]
        # for _ in tqdm(concurrent.futures.as_completed(futures), total=len(unique_encodings)):
        #     pass

        list(tqdm(executor.map(process_encoding, unique_encodings, chunksize=CHUNK_SIZE), total=len(unique_encodings)))

    package_encoding(NUM_VARS)
    



if __name__ == "__main__":
    parallel_gen()
    # non_parallel_gen()