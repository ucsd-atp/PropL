
from propositional_logic.random_gen.data import Proposition
from propositional_logic.random_gen.to_lean import to_lean_theorem_text
import os
import time
import subprocess


def get_lean_exit_status(file_path):
    try:
        # Run Lean command with the specified file path
        result = subprocess.run(['lean', file_path], capture_output=True, text=True)

        # Return the exit status
        return result.returncode

    except Exception as e:
        print(f"An error occurred: {e}")
        return None

def check_theorem_is_trivial(name : str, p : Proposition) -> bool:
    os.makedirs("_lean_check_tmp", exist_ok=True)
    current_millis = int(round(time.time() * 1000))
    fp = f"_lean_check_tmp/test_theorem_{name}_{current_millis}.lean"
    with open(fp, "w") as f:
        f.write(f"theorem {name} : {to_lean_theorem_text(p)} := by\n  simp\n")
    exit_status = get_lean_exit_status(fp)
    if exit_status == 0:
        return True
    else:
        return False

    

    
    