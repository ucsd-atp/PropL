
import os
from propositional_logic.random_gen.theorem_encoding import *
from propositional_logic.random_gen.proof_construction import *
from propositional_logic.random_gen.proof_fail_check import *
from propositional_logic.random_gen.to_lean import *
from propositional_logic.random_gen.consolidate_choices import *
from propositional_logic.random_gen.assumption_renaming import *


provable = 0
total = 0

while True:
    encoding = random.randint(0, 2 ** 200)
    prop = decode_prop(encoding, 5)
    print("number of connectives: ", count_internal_nodes(prop))
    proof = construct_proof_top_level(prop)
    print("Proof complexity")

    if not proof_has_failed(proof):
        provable += 1
    total += 1
    print(f"Provable Rate: {provable}/{total} ", provable / total)
        

