from .evaluation_access import *
from tqdm import tqdm
import concurrent.futures

def eval(id: int) -> None:

    sample_eval = SingleTheoremEval(5, id)
    tactic = ["state_0_tactic_0:","have thm1 : True := by","state_1_tactic_0:", "apply True.intro", "state_3_tactic_0:", "apply True.intro"]
    print("\n".join(tactic))
    print(sample_eval.get_initial_prompt())
    for i in range(0, len(tactic), 2):
        print("\n".join(tactic[i:i+2]))
        print(sample_eval.provide_tactic(tactic[i], tactic[i+1]))
    # print(sample_eval.provide_tactic(tactic[0], tactic[1]))
    print(sample_eval.get_current_lean_proof())


if __name__ == "__main__":
    ids = [0, 0, 0, 0, 0] * 100
    with concurrent.futures.ProcessPoolExecutor(max_workers=40) as executor:
        list(tqdm(executor.map(eval, ids)), total_length=len(ids))

    
