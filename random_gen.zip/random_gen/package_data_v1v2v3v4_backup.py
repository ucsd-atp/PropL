
import json
from propositional_logic.random_gen.gen_dataset import *
import zipfile
from datetime import datetime
from tqdm import tqdm

def package_encoding(num_vars: int) -> None:
    output_path_template = f"data_{num_vars}_vars/"
    with open(output_path_template + "_all_theorems.json", "r") as f:
        all_theorems = json.load(f)
    
    v1 = {}
    v2 = {}
    v3 = {}
    v4 = {}
    for encoding in tqdm(all_theorems):
        path_template = get_output_base_path_from_encoding(encoding, num_vars)
        with open(path_template + "v1.lean", "r") as f:
            v1[encoding] = f.read()
        with open(path_template + "v2.json", "r") as f:
            v2[encoding] = json.load(f)
        with open(path_template + "v3.json", "r") as f:
            v3[encoding] = json.load(f)
        with open(path_template + "v4.json", "r") as f:
            v4_meta = json.load(f)
            v4[encoding] = {}
            for i in range(v4_meta["completed"]):
                with open(path_template + f"v4.{i+1}.json", "r") as f:
                    v4[encoding][i] = json.load(f)
    
    with open(output_path_template + "_v1.json", "w") as f:
        json.dump(v1, f)
    with open(output_path_template + "_v2.json", "w") as f:
        json.dump(v2, f)
    with open(output_path_template + "_v3.json", "w") as f:
        json.dump(v3, f)
    with open(output_path_template + "_v4.json", "w") as f:
        json.dump(v4, f)

    # create zip file
    with zipfile.ZipFile(f"data_{num_vars}_vars_{datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}.zip", 'w') as zf:
        zf.write(output_path_template + "_all_theorems.json")
        zf.write(output_path_template + "_v1.json")
        zf.write(output_path_template + "_v2.json")
        zf.write(output_path_template + "_v3.json")
        zf.write(output_path_template + "_v4.json")

