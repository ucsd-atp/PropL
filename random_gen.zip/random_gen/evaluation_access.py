from propositional_logic.random_gen.data import *
from propositional_logic.random_gen.state_tracking_ctx import *
from propositional_logic.random_gen.theorem_encoding import *

import re

class EvaluationError(Exception):
    state_before: str
    lean_error: LeanError


tactic_label_format = re.compile(r"state_(\d+)_tactic_(\d+):")

back_track_label_format = re.compile(r"no solution, return to state (\d+) \[that leads to state (\d+)\]")

class SingleTheoremEval:

    def __init__(self, num_vars: int, encoding: int):
        # self.num_vars = num_vars
        # prop = decode_prop(encoding, num_vars)
        # self.prop = prop
        self.ctx = TacticContext(num_vars, encoding)

    def get_initial_prompt(self) -> str:
        """ Get the initial prompt for the theorem.
        Must be called before any other method.
        """
        assert self.ctx.get_cur_state_num() == 0, "Must be at initial state"
        return f"state_0:\n" + self.ctx.get_cur_tactic_state()
    
    def get_current_state_with_label(self) -> str:
        return f"state_{self.ctx.get_cur_state_num()}:\n" + \
            self.ctx.get_cur_tactic_state()

    def get_prev_state_with_label(self) -> str:
        prev_state_num = self.ctx.get_prev_state_num()
        if prev_state_num is None:
            return None
        return f"state_{prev_state_num}:\n" + \
            self.ctx.get_prev_tactic_state()

    def do_back_track(self, back_tactic: str) -> Tuple[str, str]:
        """
        Backtrack by providing the exact tactic 
        no solution, return to state (\d+) \[that leads to state (\d+)\]
        """
        state_with_label_before = self.get_current_state_with_label()

        matches = back_track_label_format.match(back_tactic)
        if matches is None:
            raise ValueError("Invalid back track label", back_tactic)
        back_track_to_state = int(matches.group(1))
        back_track_from_state = int(matches.group(2))
        if self.ctx.get_cur_state_num() != back_track_from_state:
            raise ValueError("Backtrack from the wrong state ", back_track_from_state, "expecting", self.ctx.get_cur_state_num())
        self.ctx.back_track_to_state_num(back_track_to_state)

        state_with_label_after = self.get_current_state_with_label()
        return (state_with_label_before, state_with_label_after)



    def provide_tactic(self, label: str, tactic: str) -> Tuple[str,str]:
        """
        Provide a tactic for the current state.
        Returns one or more states.
        """
        state_with_label_before = self.get_current_state_with_label()

        label = label.strip()
        tactic = tactic.strip()
        match = tactic_label_format.match(label)
        if match is None:
            raise ValueError("Invalid tactic label", label)
        state_num = int(match.group(1))
        tactic_num = int(match.group(2))
        if self.ctx.get_cur_state_num() != state_num:
            raise ValueError("Must provide tactic from the right state num", state_num, "expecting", self.ctx.get_cur_state_num())
        cache_prev_state_num = self.ctx.get_cur_state_num()
        self.ctx.push_new_state_with_tactic(tactic)
        result = []
        while True:
            new_state_num = self.ctx.get_cur_state_num()
            result.append(f"state_{new_state_num}:\n")
            try:
                current_tactic_state = self.ctx.get_cur_tactic_state()
            except LeanError as e:
                self.ctx.undo_last_push_new_state_with_tactic(new_state_num)
                raise EvaluationError(state_with_label_before, e)
            result.append(current_tactic_state + "\n")
            if current_tactic_state != "no goals":
                break
            else:
                if self.ctx.is_at_the_top_level():
                    result.append("proof is complete")
                    break
                else:
                    self.ctx.copy_state_and_decrement_indent()
        state_with_label_after =  "".join(result).strip()
        self.ctx.prev_state_nums[self.ctx.get_cur_state_num()] = cache_prev_state_num
        return (state_with_label_before, state_with_label_after)

    def get_current_lean_proof(self):
        return self.ctx.get_current_lean_proof()

if __name__ == "__main__":
    # sample_eval = SingleTheoremEval(5, 0)
    # tactic = ["state_0_tactic_0:","have thm1 : True := by","state_1_tactic_0:", "apply True.intro", "state_3_tactic_0:", "apply True.intro"]
    # print("\n".join(tactic))
    # print(sample_eval.get_initial_prompt())
    # for i in range(0, len(tactic), 2):
    #     print("\n".join(tactic[i:i+2]))
    #     print(sample_eval.provide_tactic(tactic[i], tactic[i+1]))
    # # print(sample_eval.provide_tactic(tactic[0], tactic[1]))
    # print(sample_eval.get_current_lean_proof())

    sample_eval = SingleTheoremEval(5, 346960918443446424220011675436)
    print(sample_eval.get_initial_prompt())

    tactic = [["state_0_tactic_1:", "intro h1"], ["state_1_tactic_0:", "intro h2"], ["state_2_tactic_0:", "cases h2"],
              ["state_3_tactic_0:", "case inl h3 =>"],["state_4_tactic_0:","apply Or.inl"],["state_5_tactic_2:", "intro h4"],
              ["state_6_tactic_0:","let h5 := h4.left"], ["state_7_tactic_0:","let h6 := h4.right"],["state_8_tactic_0:","apply Or.inr"],['state_9_tactic_0:', 'exact h1'],
              ['state_10_tactic_0:', 'case inr h7 =>'],['state_10_tactic_0:', 'p1 h7 =>'],['no solution, return to state 9 [that leads to state 11]'], ['state_9_tactic_0:', 'exact h3']
              ]


    for idx, entered_tactic in enumerate(tactic):
        try:
            print('==> current state is: ',sample_eval.get_current_state_with_label())
            print('==> prev state is: ',sample_eval.get_prev_state_with_label())

            print(idx)
            print('==> entered tactic is ', entered_tactic)
            if len(entered_tactic)==2:
                print(sample_eval.provide_tactic(entered_tactic[0],entered_tactic[1]))
            else:
                print(sample_eval.do_back_track(entered_tactic[0]))
        except Exception as e:
            print("==> Exception occurred")
            print(e)
            print('==> current label after error is: ', sample_eval.get_current_state_with_label())
            print('previuos state after error is',sample_eval.get_prev_state_with_label())