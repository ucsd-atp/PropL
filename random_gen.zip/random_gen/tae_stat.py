
from propositional_logic.random_gen.gen_dataset import *
from propositional_logic.random_gen.theorem_encoding import *
from propositional_logic.random_gen.data import *
from tqdm import tqdm
from propositional_logic.random_gen.package_data import *
from propositional_logic.random_gen.params import *
import matplotlib.pyplot as plt

def count_tae(encoding: int, num_vars: int) -> bool:
    prop = decode_prop(encoding, num_vars)
    proof = construct_proof_top_level(prop)
    proof = commit_drop_additional_choices_after_first_success(proof)
    return count_proof_failures(proof)

def tae_distribution() -> Dict[int, int]:
    dist = {}
    for _ in tqdm(range(1000000)):
        encoding = random.randint(0, 10 ** 30)
        tae = count_tae(encoding, NUM_VARS)
        if tae in dist:
            dist[tae] += 1
        else:
            dist[tae] = 1
    return dist

# if __name__ == "__main__":
#     print(tae_distribution())
if __name__ == "__main__":
    distribution = tae_distribution()
    print(distribution)

    # Plotting the distribution
    plt.bar(distribution.keys(), distribution.values())
    plt.xlabel('Number of Failures')
    plt.ylabel('Frequency')
    plt.title('Distribution of TAE')

    plt.xlim(0, 30)

    plt.savefig("temp_tae_distribution.png")