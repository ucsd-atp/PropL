from propositional_logic.random_gen.data import *

class AssumptionCtx():
    def __init__(self):
        self.existing = {}

    def add(self, name) -> str:
        assert name not in self.existing
        self.existing[name] = f"h{len(self.existing.keys()) + 1}"
        return self.existing[name]

    def get(self, name) -> str:
        return self.existing[name]

def rename_assumption(ctx: AssumptionCtx, p: Proof) -> Proof:
    match p:
        case ImpliesR((name, subproof)):
            return ImpliesR((ctx.add(name), rename_assumption(ctx, subproof)))
        case NegAndR(left, right):
            return NegAndR(rename_assumption(ctx, left), rename_assumption(ctx, right))
        case NegTrueR():
            return NegTrueR()
        case NegAtomR(subproof):
            return NegAtomR(rename_assumption(ctx, subproof))
        case UpshiftR(subproof):
            return UpshiftR(rename_assumption(ctx, subproof))
        case OrL(name, (left_name, left_proof), (right_name, right_proof)):
            return OrL(ctx.get(name),
                (ctx.add(left_name), rename_assumption(ctx, left_proof)),
                (ctx.add(right_name), rename_assumption(ctx, right_proof))
                )
        case FalseL(name):
            return FalseL(ctx.get(name))
        case PosAndL(name, (left_name, right_name, subproof)):
            return PosAndL(ctx.get(name),
                (ctx.add(left_name), ctx.add(right_name), rename_assumption(ctx, subproof))
                )
        case PosTrueL(name, subproof):
            return PosTrueL(ctx.get(name), rename_assumption(ctx, subproof))
        case PosAtomL(name, subproof):
            return PosAtomL(ctx.get(name), rename_assumption(ctx, subproof))
        case DownshiftL(name, subproof):
            return DownshiftL(ctx.get(name), rename_assumption(ctx, subproof))
        case StableSeq(subproof):
            return StableSeq(rename_assumption(ctx, subproof))
        case FocusR(subproof):
            return FocusR(rename_assumption(ctx, subproof))
        case FocusL(name, subproof):
            return FocusL(ctx.get(name), rename_assumption(ctx, subproof))
        case OrR_left(subproof):
            return OrR_left(rename_assumption(ctx, subproof))
        case OrR_right(subproof):
            return OrR_right(rename_assumption(ctx, subproof))
        case PosAndR(left, right):
            return PosAndR(rename_assumption(ctx, left), rename_assumption(ctx, right))
        case PosTrueR():
            return PosTrueR()
        case PosAtomR(name):
            return PosAtomR(ctx.get(name))
        case DownshiftR(subproof):
            return DownshiftR(rename_assumption(ctx, subproof))
        case ImpliesL(name, prop, left, (right_name, right_proof), additional_name):
            ctx.add(additional_name)
            return ImpliesL(ctx.get(name), prop,
                rename_assumption(ctx, left),
                (ctx.add(right_name), rename_assumption(ctx, right_proof)),
                ctx.get(additional_name)
                )
        case NegAndL_left(name, (left_name, left_proof)):
            return NegAndL_left(ctx.get(name),
                (ctx.add(left_name), rename_assumption(ctx, left_proof))
                )
        case NegAndL_right(name, (right_name, right_proof)):
            return NegAndL_right(ctx.get(name),
                (ctx.add(right_name), rename_assumption(ctx, right_proof))
                )
        case NegAtomL(name):
            return NegAtomL(ctx.get(name))
        case UpshiftL(name, subproof):
            return UpshiftL(ctx.get(name), rename_assumption(ctx, subproof))
        case FocusChoice(choices):
            return FocusChoice([rename_assumption(ctx, choice) for choice in choices])
        case NegAndL_choice(l, r):
            return NegAndL_choice(rename_assumption(ctx, l), rename_assumption(ctx, r))
        case OrR_choice(l, r):
            return OrR_choice(rename_assumption(ctx, l), rename_assumption(ctx, r))
        case ProofFailed():
            return ProofFailed()
        case _:
            raise ValueError(f"Invalid proof: {p}")


def rename_assumption_top_level(p: Proof) -> Proof:
    return rename_assumption(AssumptionCtx(), p)