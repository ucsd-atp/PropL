


from propositional_logic.random_gen.theorem_encoding import *
from propositional_logic.random_gen.output_path_util import *

def get_output_base_path_from_encoding(encoding: int, num_vars : int) -> str:
    prop = decode_prop(encoding, num_vars)
    return get_output_base_path(prop, encoding, num_vars)

def get_output_base_path(prop: Proposition, encoding: int, num_vars : int) -> str:
    return f"data_{num_vars}_vars/thm_{num_vars}_vars_{count_internal_nodes(prop)}_nodes_{encoding}."